CREATE TRIGGER webpdv.bd_usuario_cargo
BEFORE DELETE ON webpdv.usuario_cargo
FOR EACH ROW
  BEGIN
	INSERT INTO webpdv.log_usuario_cargo 
		SET id_usuario = OLD.id_usuario, id_cargo = OLD.id_cargo, id_usuario_gravacao = OLD.id_usuario_gravacao, gravacao = OLD.gravacao;
    END;
