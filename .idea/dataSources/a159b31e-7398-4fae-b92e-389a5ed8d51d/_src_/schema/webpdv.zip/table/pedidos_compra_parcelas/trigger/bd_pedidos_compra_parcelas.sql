CREATE TRIGGER bd_pedidos_compra_parcelas
BEFORE DELETE ON pedidos_compra_parcelas
FOR EACH ROW
  BEGIN 
    
    INSERT INTO `webpdv`.`log_pedidos_compra_parcelas`
        (
        `id_pedido_compra_parcela`,`id_pedido_compra`,`valor`,`data_pagamento`,`prazo`,`ordem`,
        `id_tipo_pagamento_pedido`,`id_usuario`
        )
    VALUES
        (
        OLD.`id_pedido_compra_parcela`,OLD.`id_pedido_compra`,OLD.`valor`,OLD.`data_pagamento`,OLD.`prazo`,
        OLD.`ordem`,OLD.`id_tipo_pagamento_pedido`,OLD.`id_usuario`
        );
    
    
    SET @id_log = LAST_INSERT_ID();
    
    
    INSERT INTO `webpdv`.`pedidos_compra_registro`
        (`id_pedido_compra`,`id_pedido_compra_log`,`id_usuario`,`descricao`)
    SELECT OLD.id_pedido_compra, @id_log, OLD.id_usuario, 'Deletada parcela do pedido de Compra.';
END;
