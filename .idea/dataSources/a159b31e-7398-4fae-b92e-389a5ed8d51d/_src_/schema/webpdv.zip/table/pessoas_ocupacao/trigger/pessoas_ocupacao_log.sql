CREATE TRIGGER webpdv.pessoas_ocupacao_log
BEFORE UPDATE ON webpdv.pessoas_ocupacao
FOR EACH ROW
  begin
  insert into `webpdv`.`pessoas_ocupacao_log`
SET
`id_pessoa_ocupacao` = old.id_pessoa_ocupacao,
`id_pessoa` = old.id_pessoa,
`id_tipo_atividade` = old.id_tipo_atividade,
`id_tipo_organizacao` = old.id_tipo_organizacao,
`nome_empresa` = old.nome_empresa,
`cargo` = old.cargo,
`salario` = old.salario,
`outras_rendas` = old.outras_rendas,
`id_comprovacao_renda` = old.id_comprovacao_renda,
`documento_comprovacao_renda` = old.documento_comprovacao_renda,
`data_admissao` = old.data_admissao,
`numero_matricula` = old.numero_matricula,
`telefone_comercial` = old.telefone_comercial,
`ddd_telefone_comercial` = old.ddd_telefone_comercial,
`trabalho_cep` = old.trabalho_cep,
`trabalho_logradouro` = old.trabalho_logradouro,
`trabalho_numero` = old.trabalho_numero,
`trabalho_bairro` = old.trabalho_bairro,
`trabalho_cidade` = old.trabalho_cidade,
`trabalho_uf` = old.trabalho_uf,
`trabalho_complemento` = old.trabalho_complemento,
`flag_aposentado` = old.flag_aposentado,
`flag_pensionista` = old.flag_pensionista,
`ultima_atualizacao` = old.ultima_atualizacao,
`id_usuario` = old.id_usuario;
end;
