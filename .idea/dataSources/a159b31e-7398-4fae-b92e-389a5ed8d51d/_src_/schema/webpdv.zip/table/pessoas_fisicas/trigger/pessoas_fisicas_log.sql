CREATE TRIGGER pessoas_fisicas_log
BEFORE UPDATE ON pessoas_fisicas
FOR EACH ROW
  begin
  insert into `webpdv`.`pessoas_fisicas_log`
SET
`id_pessoa_fisica` = old.id_pessoa_fisica,
`id_pessoa` = old.id_pessoa,
`rg_numero` = old.rg_numero,
`rg_orgao_expedicao` = old.rg_orgao_expedicao,
`rg_uf_expedicao` = old.rg_uf_expedicao,
`rg_data_expedicao` = old.rg_data_expedicao,
`data_nascimento` = old.data_nascimento,
`nome_pai` = old.nome_pai,
`nome_mae` = old.nome_mae,
`id_sexo` = old.id_sexo,
`id_situacao_conjugal` = old.id_situacao_conjugal,
`naturalidade` = old.naturalidade,
`nacionalidade` = old.nacionalidade,
`ultima_atualizacao` = old.ultima_atualizacao,
`id_usuario` = old.id_usuario;
end;
