CREATE TRIGGER webpdv.ai_pedidos_compra
AFTER INSERT ON webpdv.pedidos_compra
FOR EACH ROW
  BEGIN 
    
    INSERT INTO `webpdv`.`log_pedidos_compra`
        (
        `id_pedido_compra`,`storeno`,`ordno`,`vendno`,`data_faturamento`,`data_pedido`,
        `data_entrega`,`amt`,`icms`,`bln_icms_reduzido`,`icms_reduzido`,`bln_alterado`,
        `bln_permitido_comprar`,`id_situacao_pedido_compra`,`id_usuario`,`id_status`
        )
    VALUES
        (
        NEW.`id_pedido_compra`,NEW.`storeno`,NEW.`ordno`,NEW.`vendno`,NEW.`data_faturamento`,NEW.`data_pedido`,
        NEW.`data_entrega`,NEW.`amt`,NEW.`icms`,NEW.`bln_icms_reduzido`,NEW.`icms_reduzido`,NEW.`bln_alterado`,
        NEW.`bln_permitido_comprar`,NEW.`id_situacao_pedido_compra`,NEW.`id_usuario`,NEW.`id_status`
        );
    
    
    SET @id_log = LAST_INSERT_ID();
    
    
    INSERT INTO `webpdv`.`pedidos_compra_registro`
        (`id_pedido_compra`,`id_pedido_compra_log`,`id_usuario`,`descricao`)
    SELECT NEW.id_pedido_compra, @id_log, NEW.id_usuario, 'Criado um Pedido de Compra.';
END;
