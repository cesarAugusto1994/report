CREATE TRIGGER webpdv.bu_produto_valor_montagem
BEFORE UPDATE ON webpdv.produto_valor_montagem
FOR EACH ROW
  BEGIN
INSERT INTO webpdv_log.produto_valor_montagem
SET prdno = OLD.prdno,
valor_funcionario = OLD.valor_funcionario,
tipo_valor_funcionario = OLD.tipo_valor_funcionario,
valor_terceirizado = OLD.valor_terceirizado,
tipo_valor_terceirizado = OLD.tipo_valor_terceirizado,
tempo_montagem = OLD.tempo_montagem,
valor_cliente = OLD.valor_cliente,
tipo_valor_cliente = OLD.tipo_valor_cliente,
id_usuario = OLD.id_usuario,
alteracao = OLD.alteracao, 
    tipo_alteracao = 'UPDATE';
END;
