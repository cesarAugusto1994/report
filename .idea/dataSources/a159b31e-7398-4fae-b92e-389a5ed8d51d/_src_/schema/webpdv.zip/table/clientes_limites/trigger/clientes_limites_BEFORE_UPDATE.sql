CREATE TRIGGER webpdv.clientes_limites_BEFORE_UPDATE
BEFORE UPDATE ON webpdv.clientes_limites
FOR EACH ROW
  BEGIN
    INSERT INTO webpdv_log.clientes_limites SET
      id_cliente_limite = old.id_cliente_limite,
      custno = old.custno,
      id_usuario = old.id_usuario,
      data_cadastro = old.data_cadastro,
      valor_anterior = old.valor_anterior,
      valor = old.valor,
      observacao = old.observacao,
      administrativo = old.administrativo,
      ativo = old.ativo;
  END;
