CREATE TRIGGER webpdv.centrais_entrega_AUPD
AFTER UPDATE ON webpdv.centrais_entrega
FOR EACH ROW
  BEGIN
    INSERT INTO webpdv_log.centrais_entrega
    SET `storeno`                         = OLD.storeno,
      `id_central_transbordo`             = OLD.id_central_transbordo,
      `dias_bloqueio_criar_carga_veiculo` = OLD.dias_bloqueio_criar_carga_veiculo,
      `observacao`                        = OLD.observacao,
      `id_usuario_alteracao`              = NEW.id_usuario_alteracao,
      `data_alteracao`                    = NEW.data_alteracao;
  END;
