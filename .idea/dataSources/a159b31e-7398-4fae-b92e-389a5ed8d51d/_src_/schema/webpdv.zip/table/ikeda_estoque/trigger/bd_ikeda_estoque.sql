CREATE TRIGGER bd_ikeda_estoque
BEFORE DELETE ON ikeda_estoque
FOR EACH ROW
  BEGIN
	INSERT INTO webpdv_log.ikeda_estoque
		SET prdno = OLD.prdno, `prdno_grade`  = OLD.prdno_grade,  `grade` = OLD.grade, 
		`qtde_estoque` = OLD.qtde_estoque, `qtde_minima` = OLD.qtde_minima, 
		`qtty_disponivel` = OLD.qtty_disponivel, 
		`tipo_alteracao` = OLD.tipo_alteracao, `id_usuario` = OLD.id_usuario, 
		`revisao` = OLD.revisao, `ikeda_requisicao_id` = OLD.ikeda_requisicao_id, qtde_andamento = OLD.qtde_andamento;
    END;
