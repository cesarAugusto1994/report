CREATE TRIGGER webpdv.bd_pedidos_compra_faturamento
BEFORE DELETE ON webpdv.pedidos_compra_faturamento
FOR EACH ROW
  BEGIN 
    
    INSERT INTO `webpdv`.`log_pedidos_compra_faturamento`
        (
        `id_pedido_compra_faturamento`,`id_pedido_compra`,`data_faturamento`,`prazo_entrega`,
        `id_tipo_entrega`,`no_parcelas`,`forma_frete`,`id_usuario`
        )
    VALUES
        (
        OLD.`id_pedido_compra_faturamento`,OLD.`id_pedido_compra`,OLD.`data_faturamento`,OLD.`prazo_entrega`,
        OLD.`id_tipo_entrega`,OLD.`no_parcelas`,OLD.`forma_frete`,OLD.`id_usuario`
        );
    
    
    SET @id_log = LAST_INSERT_ID();
    
    
    INSERT INTO `webpdv`.`pedidos_compra_registro`
        (`id_pedido_compra`,`id_pedido_compra_log`,`id_usuario`,`descricao`)
    SELECT OLD.id_pedido_compra, @id_log, OLD.id_usuario, 'Deletado faturamento do pedido de Compra.';
END;
