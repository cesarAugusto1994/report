CREATE TRIGGER ai_pedidos_compra_faturamento
AFTER INSERT ON pedidos_compra_faturamento
FOR EACH ROW
  BEGIN 
    
    INSERT INTO `webpdv`.`log_pedidos_compra_faturamento`
        (
        `id_pedido_compra_faturamento`,`id_pedido_compra`,`data_faturamento`,`prazo_entrega`,
        `id_tipo_entrega`,`no_parcelas`,`forma_frete`,`id_usuario`
        )
    VALUES
        (
        NEW.`id_pedido_compra_faturamento`,NEW.`id_pedido_compra`,NEW.`data_faturamento`,NEW.`prazo_entrega`,
        NEW.`id_tipo_entrega`,NEW.`no_parcelas`,NEW.`forma_frete`,NEW.`id_usuario`
        );
    
    
    SET @id_log = LAST_INSERT_ID();
    
    
    INSERT INTO `webpdv`.`pedidos_compra_registro`
        (`id_pedido_compra`,`id_pedido_compra_log`,`id_usuario`,`descricao`)
    SELECT NEW.id_pedido_compra, @id_log, NEW.id_usuario, 'Adicionado um novo faturamentoao Pedido de Compra.';
END;
