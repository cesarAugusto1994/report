CREATE TRIGGER au_prestador
AFTER UPDATE ON prestador
FOR EACH ROW
  BEGIN
	INSERT INTO `webpdv_log`.`prestador` 
	 (`prestador_id`, 
	 `id_pessoa`, 
	 `prestador_tipo_id`, 
	 `nome`, 
	`funcionario_terceirizado`, 
	 `interno_externo`, 
	 `storeno`, 
	 `empno`,
	 `cpf_cnpj`, 
	 `celular_plano_empresa_ddd`, 
	 `celular_plano_empresa_numero`, 
	 `celular_pessoal_ddd`, 
	 `celular_pessoal_numero`, 
	 `id_usuario_cadastro`,
	 `cadastro`,
	 `id_usuario_inativacao`,
	 `inativacao`,
	 `status`) 
	 VALUE ( old.`id`, 
	 old.`id_pessoa`, 
	 old.`prestador_tipo_id`, 
	 old.`nome`, 
	 old.`funcionario_terceirizado`, 
	 old.`interno_externo`, 
	 old.`storeno`, 
	 old.`empno`,
	 old.`cpf_cnpj`, 
	 old.`celular_plano_empresa_ddd`, 
	 old.`celular_plano_empresa_numero`, 
	 old.`celular_pessoal_ddd`, 
	 old.`celular_pessoal_numero`, 
	 old.`id_usuario_cadastro`,
	 old.`cadastro`,
	 old.`id_usuario_inativacao`,
	 old.`inativacao`,
	 old.`status`);
    END;
