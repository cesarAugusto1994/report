CREATE TRIGGER pessoas_conjuge_log
BEFORE UPDATE ON pessoas_conjuge
FOR EACH ROW
  begin
  insert into `webpdv`.`pessoas_conjuge_log`
SET
`id_pessoa_conjuge` = old.id_pessoa_conjuge,
`id_pessoa` = old.id_pessoa,
`id_tipo_atividade_conjuge` = old.id_tipo_atividade_conjuge,
`nome_conjuge` = old.nome_conjuge,
`cpf_conjuge` = old.cpf_conjuge,
`data_nascimento_conjuge` = old.data_nascimento_conjuge,
`nome_empregador_conjuge` = old.nome_empregador_conjuge,
`cargo_conjuge` = old.cargo_conjuge,
`tempo_servico_conjuge` = old.tempo_servico_conjuge,
`salario_conjuge` = old.salario_conjuge,
`ddd_telefone_conjuge` = old.ddd_telefone_conjuge,
`numero_telefone_conjuge` = old.numero_telefone_conjuge,
`ddd_telefone_emprego_conjuge` = old.ddd_telefone_emprego_conjuge,
`numero_telefone_emprego_conjuge` = old.numero_telefone_emprego_conjuge,
`ultima_atualizacao` = old.ultima_atualizacao,
`id_usuario` = old.id_usuario;
end;
