CREATE TRIGGER webpdv.pessoas_financeiro_log
BEFORE UPDATE ON webpdv.pessoas_financeiro
FOR EACH ROW
  begin
  insert into `webpdv`.`pessoas_financeiro_log`
SET
`id_pessoa_financeiro` = old.id_pessoa_financeiro,
`id_pessoa` = old.id_pessoa,
`quantidade_dependentes` = old.quantidade_dependentes,
`quantidade_veiculos` = old.quantidade_veiculos,
`cartao_visa` = old.cartao_visa,
`cartao_master` = old.cartao_master,
`outro_cartao` = old.outro_cartao,
`nome_outro_cartao` = old.nome_outro_cartao,
`salario` = old.salario,
`outras_rendas` = old.outras_rendas,
`id_comprovacao_renda` = old.id_comprovacao_renda,
`documento_comprovacao_renda` = old.documento_comprovacao_renda,
`salario_conjuge` = old.salario_conjuge,
`ultima_atualizacao` = old.ultima_atualizacao,
`id_usuario` = old.id_usuario;
end;
