CREATE TRIGGER webpdv.pessoas_log
BEFORE UPDATE ON webpdv.pessoas
FOR EACH ROW
  begin
  insert into `webpdv`.`pessoas_log`
  SET
  `id_pessoa` = old.id_pessoa,
  `id_tipo_pessoa` = old.id_tipo_pessoa,
  `custno` = old.custno,
  `vendno` = old.vendno,
  `cpf_cnpj` = old.cpf_cnpj,
  `nome_pessoa` = old.nome_pessoa,
  `nome_tratamento` = old.nome_tratamento,
  `telefone` = old.telefone,
  `ddd_telefone` = old.ddd_telefone,
  `email` = old.email,
  `telefone2` = old.telefone2,
  `ddd_telefone2` = old.ddd_telefone2,
  `contato_telefone2` = old.contato_telefone2,
  `data_cadastro` = old.data_cadastro,
  `ultima_atualizacao` = old.ultima_atualizacao,
  `id_usuario_atualizacao` = old.id_usuario_atualizacao;
end;
