CREATE TRIGGER webpdv.produto_campo_livre_AUPD
AFTER UPDATE ON webpdv.produto_campo_livre
FOR EACH ROW
  BEGIN

  INSERT INTO webpdv_log.produto_campo_livre
  SET prdno              = OLD.prdno,
    taxno                = OLD.taxno,
    garantia             = OLD.garantia,
    prazo_medio          = OLD.prazo_medio,
    campo_livre_3        = OLD.campo_livre_3,
    campo_livre_4        = OLD.campo_livre_4,
    id_usuario_alteracao = NEW.id_usuario_alteracao,
    data_alteracao       = NEW.data_alteracao;

  UPDATE sqldados.prd
  SET taxno = NEW.taxno, garantia = NEW.garantia, free_fld1 = NEW.prazo_medio,
    free_fld3 = NEW.campo_livre_3, free_fld4 = NEW.campo_livre_4
  WHERE prd.NO = NEW.prdno;

  UPDATE sqlsi.prd
  SET taxno = NEW.taxno, garantia = NEW.garantia, free_fld1 = NEW.prazo_medio,
    free_fld3 = NEW.campo_livre_3, free_fld4 = NEW.campo_livre_4
  WHERE prd.NO = NEW.prdno;

END;
