CREATE TRIGGER webpdv.au_usuarios
AFTER UPDATE ON webpdv.usuarios
FOR EACH ROW
  BEGIN
	INSERT INTO webpdv.log_usuarios 
		SET id_usuario = OLD.id_usuario, id_grupo_usuario = OLD.id_grupo_usuario, login = OLD.login, 
		PASSWORD = OLD.password, nome_usuario = OLD.nome_usuario, ativo = OLD.ativo, id_loja = OLD.id_loja, 
		id_user_saci = OLD.id_user_saci, centro_lucro = OLD.centro_lucro, alcada = OLD.alcada, 
		analista_local_geral = OLD.analista_local_geral, vendno = OLD.vendno, 
		id_usuario_modelo = OLD.id_usuario_modelo, pdvno = OLD.pdvno, 
		hora_inicio = OLD.hora_inicio, hora_fim = OLD.hora_fim, 
		hora_inicio_sabado = OLD.hora_inicio_sabado, hora_fim_sabado = OLD.hora_fim_sabado, 
		empno = OLD.empno, email = OLD.email, id_usuario_alteracao = OLD.id_usuario_alteracao, 
		alteracao = OLD.alteracao;
    END;
