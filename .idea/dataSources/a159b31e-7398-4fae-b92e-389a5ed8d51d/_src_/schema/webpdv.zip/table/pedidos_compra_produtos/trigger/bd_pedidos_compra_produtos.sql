CREATE TRIGGER webpdv.bd_pedidos_compra_produtos
BEFORE DELETE ON webpdv.pedidos_compra_produtos
FOR EACH ROW
  BEGIN 
    
    INSERT INTO `webpdv`.`log_pedidos_compra_produtos`
        (
        `id_pedido_compra_produto`,`id_pedido_compra`,`id_situacao_pedido_compra_cfo`,`prdno`,`grade`,
        `qtty`,`cost`,`frete`,`tipo_valor_frete`,`ipi`,`icms`,`bln_disponibilidade`,`data_entrega_cliente`,
        `id_produto_disponibilidade_futura`,`id_usuario`
        )
    VALUES
        (
        OLD.`id_pedido_compra_produto`,OLD.`id_pedido_compra`,OLD.`id_situacao_pedido_compra_cfo`,OLD.`prdno`,OLD.`grade`,
        OLD.`qtty`,OLD.`cost`,OLD.`frete`,OLD.`tipo_valor_frete`,OLD.`ipi`,OLD.`icms`,OLD.`bln_disponibilidade`,OLD.`data_entrega_cliente`,
        OLD.`id_produto_disponibilidade_futura`,OLD.`id_usuario`
        );
    
    
    SET @id_log = LAST_INSERT_ID();
    
    
    INSERT INTO `webpdv`.`pedidos_compra_registro`
        (`id_pedido_compra`,`id_pedido_compra_log`,`id_usuario`,`descricao`)
    SELECT OLD.id_pedido_compra, @id_log, OLD.id_usuario, 'Deletado produto do pedido de Compra.';
END;
