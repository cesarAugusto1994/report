CREATE TRIGGER webpdv.ai_pedidos_compra_produtos
AFTER INSERT ON webpdv.pedidos_compra_produtos
FOR EACH ROW
  BEGIN 
    
    INSERT INTO `webpdv`.`log_pedidos_compra_produtos`
        (
        `id_pedido_compra_produto`,`id_pedido_compra`,`id_situacao_pedido_compra_cfo`,`prdno`,`grade`,
        `qtty`,`cost`,`frete`,`tipo_valor_frete`,`ipi`,`icms`,`bln_disponibilidade`,`data_entrega_cliente`,
        `id_produto_disponibilidade_futura`,`id_usuario`
        )
    VALUES
        (
        NEW.`id_pedido_compra_produto`,NEW.`id_pedido_compra`,NEW.`id_situacao_pedido_compra_cfo`,NEW.`prdno`,NEW.`grade`,
        NEW.`qtty`,NEW.`cost`,NEW.`frete`,NEW.`tipo_valor_frete`,NEW.`ipi`,NEW.`icms`,NEW.`bln_disponibilidade`,NEW.`data_entrega_cliente`,
        NEW.`id_produto_disponibilidade_futura`,NEW.`id_usuario`
        );
    
    
    SET @id_log = LAST_INSERT_ID();
    
    
    INSERT INTO `webpdv`.`pedidos_compra_registro`
        (`id_pedido_compra`,`id_pedido_compra_log`,`id_usuario`,`descricao`)
    SELECT NEW.id_pedido_compra, @id_log, NEW.id_usuario, 'Adicionado um novo produto ao Pedido de Compra.';
END;
