CREATE TRIGGER veiculos_BUPD
BEFORE UPDATE ON veiculos
FOR EACH ROW
  BEGIN
  INSERT INTO `webpdv_log`.`veiculos`
  SET `id_veiculo`          = OLD.id_veiculo,
    `placa`                 = OLD.placa,
    `veiculo`               = OLD.veiculo,
    `renavam`               = OLD.renavam,
    `ano`                   = OLD.ano,
    `modelo`                = OLD.modelo,
    `data_aquisicao`        = OLD.data_aquisicao,
    `id_combustivel`        = OLD.id_combustivel,
    `carga_max`             = OLD.carga_max,
    `id_produto`            = OLD.id_produto,
    `km_atual`              = OLD.km_atual,
    `ativo`                 = OLD.ativo,
    `id_loja`               = OLD.id_loja,
    `id_categoria`          = OLD.id_categoria,
    `desempenho`            = OLD.desempenho,
    `responsavel`           = OLD.responsavel,
    `valor_veiculo`         = OLD.valor_veiculo,
    `capacidade_tanque`     = OLD.capacidade_tanque,
    `desempenho_referencia` = OLD.desempenho_referencia,
    `id_empresa`            = OLD.id_empresa,
    `id_tipo_aquisicao`     = OLD.id_tipo_aquisicao,
    `id_validar_controle`   = OLD.id_validar_controle,
    `km_cadastro`           = OLD.km_cadastro,
    `tipo_veiculo`          = OLD.tipo_veiculo,
    `capacidade_cubica`     = OLD.capacidade_cubica,
    `data_cadastro`         = OLD.data_cadastro,
    `id_usuario_cadastro`   = OLD.id_usuario_cadastro,
    `data_atualizacao`      = NEW.data_atualizacao,
    `id_usuario_atualizacao`= NEW.id_usuario_atualizacao;
END;
