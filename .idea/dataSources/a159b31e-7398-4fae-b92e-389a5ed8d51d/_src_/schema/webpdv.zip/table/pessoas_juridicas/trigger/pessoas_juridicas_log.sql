CREATE TRIGGER webpdv.pessoas_juridicas_log
BEFORE UPDATE ON webpdv.pessoas_juridicas
FOR EACH ROW
  begin
  insert into `webpdv`.`pessoas_juridicas_log`
SET
`id_pessoa_juridica` = old.id_pessoa_juridica,
`id_pessoa` = old.id_pessoa,
`inscricao_estadual` = old.inscricao_estadual,
`inscricao_estadual_subst_trib` = old.inscricao_estadual_subst_trib,
`inscricao_municipal` = old.inscricao_municipal,
`nome_responsavel` = old.nome_responsavel,
`cpf_responsavel` = old.cpf_responsavel,
`rg_responsavel` = old.rg_responsavel,
`rg_orgao_expedicao` = old.rg_orgao_expedicao,
`rg_uf_expedicao` = old.rg_uf_expedicao,
`data_abertura` = old.data_abertura,
`id_ramo_atividade` = old.id_ramo_atividade,
`id_tipo_organizacao` = old.id_tipo_organizacao,
`id_responsavel` = old.id_responsavel,
`ultima_atualizacao` = old.ultima_atualizacao,
`id_usuario` = old.id_usuario;
end;
