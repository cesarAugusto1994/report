CREATE TRIGGER webpdv.produto_caracteristica_AUPD
AFTER UPDATE ON webpdv.produto_caracteristica
FOR EACH ROW
  BEGIN

  INSERT INTO webpdv_log.produto_caracteristica
  SET prdno                 = OLD.prdno,
    fora_linha              = OLD.fora_linha,
    fracionado              = OLD.fracionado,
    estoque_minimo          = OLD.estoque_minimo,
    revenda                 = OLD.revenda,
    imobilizado             = OLD.imobilizado,
    uso_consumo             = OLD.uso_consumo,
    servico                 = OLD.servico,
    prod_kit                = OLD.prod_kit,
    vendido_kit             = OLD.vendido_kit,
    garantia                = OLD.garantia,
    sem_estoque             = OLD.sem_estoque,
    nao_requer_montagem     = OLD.nao_requer_montagem,
    produto_situacao_mix_id = OLD.produto_situacao_mix_id,
    voltagem                = OLD.voltagem,
    id_usuario_alteracao    = NEW.id_usuario_alteracao,
    data_alteracao          = NEW.data_alteracao;

  UPDATE sqldados.prd
  SET dereg = (NEW.fora_linha*4 + NEW.fracionado*16 + NEW.servico*64 + NEW.prod_kit*256),
    minstk = NEW.estoque_minimo, auxshort2 = NEW.nao_requer_montagem
  WHERE prd.no = new.prdno;

  UPDATE sqlsi.prd
  SET dereg = (NEW.fora_linha*4 + NEW.fracionado*16 + NEW.servico*64 + NEW.prod_kit*256),
    minstk = NEW.estoque_minimo, auxshort2 = NEW.nao_requer_montagem
  WHERE prd.no = new.prdno;

END;
