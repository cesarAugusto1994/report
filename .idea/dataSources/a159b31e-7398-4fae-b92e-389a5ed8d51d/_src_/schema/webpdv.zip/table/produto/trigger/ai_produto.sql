CREATE TRIGGER ai_produto
AFTER INSERT ON produto
FOR EACH ROW
  BEGIN
DECLARE bln_existe_registro BOOLEAN;
SELECT EXISTS(SELECT 'x'
FROM sqldados.prd
WHERE prd.NO = NEW.prdno) INTO bln_existe_registro;
IF(0 = bln_existe_registro)
THEN 
INSERT INTO sqldados.prd
SET NO = NEW.prdno, mfno = NEW.vendno, clno = NEW.clno, deptno = NEW.deptno, typeno = NEW.typeno, NAME = substring(NEW.NAME,1, 38);
INSERT INTO sqlsi.prd
SET NO = NEW.prdno, mfno = NEW.vendno, clno = NEW.clno, deptno = NEW.deptno, typeno = NEW.typeno, NAME = substring(NEW.NAME,1, 38);
END IF;
END;
