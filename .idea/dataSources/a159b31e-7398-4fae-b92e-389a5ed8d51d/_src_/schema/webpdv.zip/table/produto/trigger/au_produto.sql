CREATE TRIGGER au_produto
AFTER UPDATE ON produto
FOR EACH ROW
  BEGIN

  INSERT INTO webpdv_log.produto

  SET prdno              = OLD.prdno,
    clno                 = OLD.clno,
    name                 = OLD.name,
    vendno               = OLD.vendno,
    typeno               = OLD.typeno,
    deptno               = OLD.deptno,
    groupno              = OLD.groupno,
    unidade              = OLD.unidade,
    prdno_int            = OLD.prdno_int,
    id_usuario_alteracao = NEW.id_usuario_alteracao,
    data_alteracao       = NEW.data_alteracao;

  UPDATE sqldados.prd
  SET mfno = NEW.vendno, clno = NEW.clno, deptno = NEW.deptno, typeno = NEW.typeno, NAME = substring(NEW.NAME,1, 38), barcode = new.cod_barra
  WHERE prd.NO = NEW.prdno;

  UPDATE sqlsi.prd
  SET mfno = NEW.vendno, clno = NEW.clno, deptno = NEW.deptno, typeno = NEW.typeno, NAME = substring(NEW.NAME,1, 38), barcode = new.cod_barra
  WHERE prd.NO = NEW.prdno;
END;
