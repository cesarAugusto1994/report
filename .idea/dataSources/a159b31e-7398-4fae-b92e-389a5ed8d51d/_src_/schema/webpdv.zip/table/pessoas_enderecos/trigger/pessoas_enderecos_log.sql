CREATE TRIGGER pessoas_enderecos_log
BEFORE UPDATE ON pessoas_enderecos
FOR EACH ROW
  begin
  insert into `webpdv`.`pessoas_enderecos_log`
SET
`id_pessoa_endereco` = old.id_pessoa_endereco,
`id_pessoa` = old.id_pessoa,
`localno` = old.localno,
`endereco_cep` = old.endereco_cep,
`endereco_logradouro` = old.endereco_logradouro,
`endereco_numero` = old.endereco_numero,
`endereco_complemento` = old.endereco_complemento,
`endereco_bairro` = old.endereco_bairro,
`endereco_cidade` = old.endereco_cidade,
`endereco_uf` = old.endereco_uf,
`endereco_ponto_referencia` = old.endereco_ponto_referencia,
`id_tipo_residencia` = old.id_tipo_residencia,
`valor_aluguel` = old.valor_aluguel,
`tempo_residencia` = old.tempo_residencia,
`id_comprovacao_residencia` = old.id_comprovacao_residencia,
`documento_comprovacao_residencia` = old.documento_comprovacao_residencia,
`telefone_residencial` = old.telefone_residencial,
`ddd_telefone_residencial` = old.ddd_telefone_residencial,
`ultimo_localno` = old.ultimo_localno,
`ultimo_endereco_cep` = old.ultimo_endereco_cep,
`ultimo_endereco_logradouro` = old.ultimo_endereco_logradouro,
`ultimo_endereco_numero` = old.ultimo_endereco_numero,
`ultimo_endereco_bairro` = old.ultimo_endereco_bairro,
`ultimo_endereco_cidade` = old.ultimo_endereco_cidade,
`ultimo_endereco_uf` = old.ultimo_endereco_uf,
`ultimo_endereco_complemento` = old.ultimo_endereco_complemento,
`ultimo_endereco_ponto_referencia` = old.ultimo_endereco_ponto_referencia,
`spedcidno` = old.spedcidno,
`endereco_ultima_atualizacao` = old.endereco_ultima_atualizacao,
`endereco_id_usuario_atualizacao` = old.endereco_id_usuario_atualizacao,
`ultima_atualizacao` = old.ultima_atualizacao,
`id_usuario` = old.id_usuario
;
end;
