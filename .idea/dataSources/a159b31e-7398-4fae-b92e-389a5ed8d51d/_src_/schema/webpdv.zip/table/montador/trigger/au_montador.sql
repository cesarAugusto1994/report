CREATE TRIGGER webpdv.au_montador
AFTER UPDATE ON webpdv.montador
FOR EACH ROW
  BEGIN
  INSERT INTO webpdv_log.montador
  (prestador_id, veiculo_da_empresa, usa_veiculo, horas_maxima_montagem, prazo_confirmacao_montagem, id_veiculo, id_usuario_alteracao, alteracao)
  VALUES (OLD.prestador_id, OLD.veiculo_da_empresa, OLD.usa_veiculo, OLD.horas_maxima_montagem,
          OLD.prazo_confirmacao_montagem, OLD.id_veiculo, NEW.id_usuario_alteracao, NEW.alteracao);
END;
