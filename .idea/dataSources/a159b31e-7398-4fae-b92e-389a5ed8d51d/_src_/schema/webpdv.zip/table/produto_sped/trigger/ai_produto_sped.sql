CREATE TRIGGER ai_produto_sped
AFTER INSERT ON produto_sped
FOR EACH ROW
  BEGIN
	DECLARE bln_existe_registro BOOLEAN;
	SELECT EXISTS(SELECT 'x'
	FROM sqldados.spedprd
	WHERE spedprd.prdno = NEW.prdno) INTO bln_existe_registro;
	
	IF(0 = bln_existe_registro)
	THEN
		INSERT INTO sqldados.spedprd
			SET prdno = NEW.prdno, ncm = NEW.ncm;
		INSERT INTO sqlsi.spedprd
			SET prdno = NEW.prdno, ncm = NEW.ncm;
	END IF;
    END;
