CREATE TRIGGER produto_sped_AUPD
AFTER UPDATE ON produto_sped
FOR EACH ROW
  BEGIN

  INSERT INTO webpdv_log.produto_sped
  SET

    prdno                = OLD.prdno,
    ncm                  = OLD.ncm,
    origem               = OLD.origem,
    id_usuario_alteracao = NEW.id_usuario_alteracao,
    data_alteracao       = NEW.data_alteracao;
  UPDATE sqldados.spedprd
  SET ncm = NEW.ncm
  WHERE prdno = NEW.prdno;

  UPDATE sqlsi.spedprd
  SET ncm = NEW.ncm
  WHERE prdno = NEW.prdno;
END;
