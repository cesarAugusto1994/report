CREATE PROCEDURE produtos_busca_brindes_produto(IN storeno INT, IN prdno INT, IN data_validade VARCHAR(10))
  BEGIN
	SELECT produtos_brindes.* 
	FROM produtos_brindes 
	WHERE (produtos_brindes.id_loja = 0 OR produtos_brindes.id_loja = storeno)
	AND produtos_brindes.id_produto = prdno 
	AND data_validade_inicio <= data_validade 
	AND data_validade_fim >= data_validade;
	
    END;
