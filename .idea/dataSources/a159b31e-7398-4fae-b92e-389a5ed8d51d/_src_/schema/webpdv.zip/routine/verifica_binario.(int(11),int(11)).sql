CREATE FUNCTION webpdv.verifica_binario(valor INT, binario INT)
  RETURNS INT
  BEGIN
	DECLARE controle INT DEFAULT 14;
	DECLARE potencia INT;
	
	IF 0 > valor 
	THEN 
		IF binario = -32768 
		THEN RETURN(1);
		END IF;
		SET valor = valor + 32768;
	ELSE 
		IF binario = -32768
		THEN RETURN(0);
		END IF;
	END IF;
	
	loop1: WHILE controle > 0 DO
		
		SET potencia = pow(2, controle);
		IF (potencia <= valor)
		THEN 
			IF binario = potencia
			THEN RETURN(1);
			END IF;
			SET valor = valor - potencia;
		ELSE
			IF binario = potencia
			THEN RETURN(0);
			END IF;
		END IF;
		SET controle = controle - 1;
	END WHILE loop1;
	    END;
