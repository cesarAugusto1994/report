CREATE FUNCTION assistencia_visita_avaliador(idAssistenciaVisita INT)
  RETURNS TINYINT(1)
  BEGIN
declare retorno tinyint(1);

	select exists (
	SELECT *
	FROM
	(select ass.id_assistencia, ass.prdno, ce.storeno, le.id_linha_entrega, av.tipo_visita,
		webpdv.produto_especialidade_assistencia_visita(ass.prdno) AS assistencia_visita_especialidade_id
		from webpdv.assistencia_visita av
		left join webpdv.assistencia ass ON (ass.id_assistencia = av.id_assistencia)
		left join webpdv.centrais_entrega ce ON (ce.storeno = ass.central_entrega)
		left join webpdv.linhas_entregas_itinerarios lei ON (lei.id_entrega_itinerario = ass.id_entrega_itinerario)
		left join webpdv.linhas_entrega le ON (le.id_linha_entrega = lei.id_linha_entrega)
		where av.id_assistencia_visita = idAssistenciaVisita) t1
		WHERE exists (
			select *
			from webpdv.assistencia_visita_especialidade_parametrizacao vep
			where vep.assistencia_visita_especialidade_id = t1.assistencia_visita_especialidade_id
			and vep.tipo = 'Central Entrega'
			and vep.identificador = t1.storeno
			and vep.visita_tipo = t1.tipo_visita
			and vep.ativo = 1

			union

			select *
			from webpdv.assistencia_visita_especialidade_parametrizacao vep
			where vep.assistencia_visita_especialidade_id = t1.assistencia_visita_especialidade_id
			and vep.tipo = 'Linha Entrega'
			and vep.identificador = t1.id_linha_entrega
			and vep.visita_tipo = t1.tipo_visita
			and vep.ativo = 1
		)
	) as assistenciaFeitaPeloVisitante INTO retorno;
	RETURN retorno;
END;
