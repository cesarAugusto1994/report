CREATE FUNCTION webpdv.entregas_busca_data_agendamento_itinerario(l_int_id_entrega_itinerario INT)
  RETURNS VARCHAR(10)
  BEGIN
	DECLARE l_str_data_proximo_agendamento VARCHAR(10);
	
	SELECT DATE_FORMAT(MIN(data_entrega), '%Y/%m/%d') INTO l_str_data_proximo_agendamento
	FROM webpdv.pedidos_entregas pe
	WHERE pe.id_entrega_itinerario = l_int_id_entrega_itinerario
	AND pe.id_status_entrega = 1
	AND pe.data_entrega > CURDATE()
	GROUP BY pe.id_entrega_itinerario;
	RETURN l_str_data_proximo_agendamento;
    END;
