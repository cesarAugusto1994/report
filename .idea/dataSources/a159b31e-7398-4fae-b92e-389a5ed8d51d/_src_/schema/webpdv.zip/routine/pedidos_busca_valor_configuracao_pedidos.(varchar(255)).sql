CREATE PROCEDURE webpdv.pedidos_busca_valor_configuracao_pedidos(IN l_str_nome_configuracao VARCHAR(255))
  BEGIN
      SELECT valor_configuracao FROM webpdv.configuracoes_pedidos WHERE nome_configuracao = l_str_nome_configuracao;
    END;
