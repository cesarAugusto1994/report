CREATE FUNCTION webpdv.entregaVerificarAlerta(idPedidoEntrega INT, prazoConsiderarAlerta INT)
  RETURNS TINYINT(1)
  BEGIN
	DECLARE retorno BOOLEAN;
	# ALERTA
	SELECT 
	IF(
	 webpdv.entregaVerificarAtraso(idPedidoEntrega) = 1,
	    0,
	    IF( (0 < pe.agendamento_entrega) ,
	   IF( (0 < pe.agendamento_entrega) AND ( DATE_SUB(date_format(pe.agendamento_entrega, '%Y-%m-%d'), INTERVAL prazoConsiderarAlerta DAY) <= DATE_FORMAT(NOW(), '%Y-%m-%d')),
	    1,
	    0
	   ),
	   IF( ( DATE_SUB(DATE_FORMAT(pe.previsao_entrega, '%Y-%m-%d'), INTERVAL prazoConsiderarAlerta DAY) <= DATE_FORMAT(NOW(), '%Y-%m-%d')),
	    1,
	    0
	   )
	  )
	) INTO retorno
	FROM webpdv.pedidos_entregas pe
	WHERE id_pedido_entrega = idPedidoEntrega;
	
	RETURN retorno;
    END;
