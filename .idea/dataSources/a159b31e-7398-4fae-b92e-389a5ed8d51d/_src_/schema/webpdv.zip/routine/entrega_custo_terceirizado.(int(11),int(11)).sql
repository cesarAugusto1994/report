CREATE FUNCTION webpdv.entrega_custo_terceirizado(idEntregaItinerario INT, dataVenda INT)
  RETURNS INT
  BEGIN
DECLARE dataInicio DATETIME;
DECLARE dataFim DATETIME;
DECLARE custoEntrega INT;

select DATE_FORMAT(dataVenda, '%Y-%m-%d 00:00:00') INTO dataInicio;
select DATE_FORMAT(dataVenda, '%Y-%m-%d 23:59:59') INTO dataFim;

SELECT IFNULL(MAX(custo_entrega), 0) INTO custoEntrega
FROM (
select custo_entrega
from webpdv.entrega_itinerario_prestador eip
INNER JOIN webpdv.prestador p
	ON(p.id = eip.prestador_id 
		AND (p.status = 1 
        OR 
			(p.status = 0 and p.inativacao >= dataFim)
        ) 
	)
where eip.id_entrega_itinerario = idEntregaItinerario
AND eip.criacao <= dataFim 
and eip.status = 1

UNION all

select custo_entrega
from webpdv.entrega_itinerario_prestador eip
INNER JOIN webpdv.prestador p
	ON(p.id = eip.prestador_id 
		AND (p.status = 1 
        OR 
			(p.status = 0 and p.inativacao >= dataFim)
        ) 
	)
where eip.id_entrega_itinerario = idEntregaItinerario
AND eip.criacao <= dataFim 
AND eip.inativacao >= dataInicio
and eip.status = 0 ) t1;

RETURN custoEntrega;
END;
