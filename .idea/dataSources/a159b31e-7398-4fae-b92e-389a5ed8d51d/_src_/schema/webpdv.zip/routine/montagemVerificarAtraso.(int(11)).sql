CREATE FUNCTION montagemVerificarAtraso(idPedidoEntrega INT)
  RETURNS TINYINT(1)
  BEGIN
    DECLARE retorno BOOLEAN;
    # MONTAGEM ATRASO
    SELECT IF(0 < m.data_agendamento, IF(MIN(m.data_agendamento) < DATE_FORMAT(NOW(), '%Y-%m-%d'), 1, 0),
              IF(0 < pe.data_agendamento_montagem,
                 IF(pe.data_agendamento_montagem < DATE_FORMAT(NOW(), '%Y-%m-%d'), 1, 0),
                 IF(pe.previsao_montagem < DATE_FORMAT(NOW(), '%Y%m%d'), 1, 0)
              ))
    INTO retorno
    FROM webpdv.pedidos_entregas pe
      LEFT JOIN webpdv.montagens m ON (m.id_origem = pe.id_pedido_entrega AND m.tipo = 'ENTREGA')
    WHERE id_pedido_entrega = idPedidoEntrega;
    RETURN retorno;
  END;
