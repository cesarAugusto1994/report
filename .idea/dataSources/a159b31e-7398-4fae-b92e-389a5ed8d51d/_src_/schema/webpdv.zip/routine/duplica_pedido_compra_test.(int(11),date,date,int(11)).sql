CREATE FUNCTION duplica_pedido_compra_test(idPedidoCompra INT, dataEntregaNovo DATE, dataFaturamentoNovo DATE,
                                           newStoreno     INT)
  RETURNS INT
  BEGIN

    DECLARE idPedidoEntregaNovo INT;
    DECLARE ordnoNovo INT;

    DECLARE storenoTemp INT;
    DECLARE vendnoTemp INT;
    DECLARE ordnoTemp INT;

    DECLARE intUltimaLinha INT;
    DECLARE intPedidoCompraProduto INT;
    DECLARE idPedidoCompraProduto INT;
    DECLARE idProdutoDisponibilidadeFutura INT;
    DECLARE arrProdutos CURSOR FOR
      SELECT id_pedido_compra_produto
      FROM webpdv.pedido_compra_produto pcp
      WHERE pcp.id_pedido_compra = idPedidoCompra;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET intUltimaLinha = 1;

    SELECT storeno
    FROM webpdv.pedidos_compra
    WHERE `id_pedido_compra` = idPedidoCompra
    INTO storenoTemp;
    SELECT vendno
    FROM webpdv.pedidos_compra
    WHERE `id_pedido_compra` = idPedidoCompra
    INTO vendnoTemp;
    SELECT ordno
    FROM webpdv.pedidos_compra
    WHERE `id_pedido_compra` = idPedidoCompra
    INTO ordnoTemp;

    SELECT MAX(NO) + 1
    FROM sqldados.ords
    WHERE storeno = storenoTemp
    INTO ordnoNovo;

    INSERT INTO `sqldados`.`ords`
    (`no`, `date`, `discount`, `amt`, `package`, `custo_fin`, `others`, `eord_ordno`, `dataFaturamento`, `invno`, `freightAmt`, `auxLong1`,
     `auxLong2`, `amtOrigem`, `dataEntrega`, `vendno`, `deliv`, `storeno`, `carrno`, `empno`, `prazo`, `eord_storeno`, `delivOriginal`, `bits`,
     `bits2`, `padbyte`, `indxno`, `repno`, `auxShort1`, `auxShort2`, `noofinst`, `status`, `frete`, `remarks`, `ordnoFromVend`, `remarksInv`,
     `remarksRcv`, `remarksOrd`, `auxChar`)
      SELECT
        ordnoNovo,
        DATE_FORMAT(CURDATE(), '%Y%m%d'),
        `discount`,
        `amt`,
        `package`,
        `custo_fin`,
        `others`,
        `eord_ordno`,
        DATE_FORMAT(dataFaturamentoNovo, '%Y%m%d'),
        `invno`,
        `freightAmt`,
        `auxLong1`,
        `auxLong2`,
        `amtOrigem`,
        DATE_FORMAT(dataEntregaNovo, '%Y%m%d'),
        `vendno`,
        `deliv`,
        `storeno`,
        `carrno`,
        `empno`,
        `prazo`,
        `eord_storeno`,
        `delivOriginal`,
        `bits`,
        `bits2`,
        `padbyte`,
        `indxno`,
        `repno`,
        `auxShort1`,
        `auxShort2`,
        `noofinst`,
        `status`,
        `frete`,
        `remarks`,
        `ordnoFromVend`,
        `remarksInv`,
        `remarksRcv`,
        `remarksOrd`,
        `auxChar`
      FROM `sqldados`.`ords`
      WHERE `storeno` = storenoTemp AND `no` = ordnoTemp;

    /*
    INSERT INTO `sqldados`.`oprd`
    (`ordno`,`mult`,`ipi`,`freight`,`icms`,`auxLong1`,`auxLong2`,`auxMy1`,`auxMy2`,`icmsSubst`,`auxLong3`,`auxLong4`,`auxMy3`,
     `auxMy4`,`qtty`,`qtty_src`,`qtty_xfr`,`cost`,`qttyRcv`,`qttyCancel`,`qttyVendaMes`,`qttyVendaMesAnt`,`qttyVendaMedia`,
     `qttyPendente`,`stkDisponivel`,`qttyAbc`,`storeno`,`seqno`,`status`,`bits`,`bits2`,`auxShort1`,`auxShort2`,`auxShort3`,
     `auxShort4`,`prdno`,`grade`,`remarks`,`padbyte`,`gradeFechada`,`obs`,`auxStr`)
      SELECT ordnoNovo,`mult`,`ipi`,`freight`,`icms`,`auxLong1`,`auxLong2`,`auxMy1`,`auxMy2`,`icmsSubst`,`auxLong3`,`auxLong4`,`auxMy3`,
        `auxMy4`,`qtty`,`qtty_src`,`qtty_xfr`,`cost`,`qttyRcv`,`qttyCancel`,`qttyVendaMes`,`qttyVendaMesAnt`,`qttyVendaMedia`,
        `qttyPendente`,`stkDisponivel`,`qttyAbc`,`storeno`,`seqno`,`status`,`bits`,`bits2`,`auxShort1`,`auxShort2`,`auxShort3`,
        `auxShort4`,`prdno`,`grade`,`remarks`,`padbyte`,`gradeFechada`,`obs`,`auxStr`
      FROM `sqldados`.`oprd`
      WHERE `storeno` = storenoTemp AND `ordno` = ordnoTemp;

      INSERT INTO `sqldados`.`opay`
      (`ordno`,`amt`,`duedate`,`storeno`,`padbyte`)
        SELECT ordnoNovo,`opay`.`amt`,
          DATE_FORMAT(DATE_ADD(dataFaturamentoNovo, INTERVAL ( DATEDIFF(`opay`.`duedate`, `ords`.`date`) ) DAY), '%Y%m%d'),
          storenoTemp,''
        FROM `sqldados`.`opay`
          LEFT JOIN `sqldados`.`ords` ON  (ords.storeno = opay.storeno AND ords.no = opay.ordno)
        WHERE `opay`.`storeno` = storenoTemp
              AND `opay`.`ordno` = ordnoTemp;
    */
    INSERT INTO `webpdv`.`pedidos_compra`
    (`storeno`, `ordno`, `vendno`,
     espec_doc_fiscal_codigo, `data_faturamento`, `data_pedido`, `data_entrega`, `amt`,
     `icms`, `bln_icms_reduzido`, `icms_reduzido`, `bln_alterado`, bln_permitido_comprar, bln_editado,
     `id_situacao_pedido_compra`, `id_usuario`, atualizacao, `id_status`)
      SELECT
        newStoreno AS storeno,
        ordnoNovo,
        `vendno`,
        espec_doc_fiscal_codigo,
        DATE_FORMAT(dataFaturamentoNovo, '%Y%m%d'),
        DATE_FORMAT(CURDATE(), '%Y%m%d'),
        DATE_FORMAT(dataEntregaNovo, '%Y%m%d'),
        `amt`,
        `icms`,
        `bln_icms_reduzido`,
        `icms_reduzido`,
        1,
        bln_permitido_comprar,
        bln_editado,
        `id_situacao_pedido_compra`,
        `id_usuario`,
        NOW(),
        1
      FROM `webpdv`.`pedidos_compra`
      WHERE `id_pedido_compra` = idPedidoCompra;

    SET idPedidoEntregaNovo = LAST_INSERT_ID();

    INSERT INTO `webpdv`.`pedidos_compra_faturamento`
    (`id_pedido_compra`, `data_faturamento`, `prazo_entrega`, `id_tipo_entrega`, `no_parcelas`,
     forma_frete, vendor, atualizacao)
      SELECT
        idPedidoEntregaNovo,
        DATE_FORMAT(dataFaturamentoNovo, '%Y%m%d'),
        `prazo_entrega`,
        `id_tipo_entrega`,
        `no_parcelas`,
        forma_frete,
        vendor,
        NOW()
      FROM `webpdv`.`pedidos_compra_faturamento`
      WHERE `id_pedido_compra` = idPedidoCompra;
    /*
      INSERT INTO `webpdv`.`pedidos_compra_parcelas`
      (`id_pedido_compra`,`valor`,`data_pagamento`,`prazo`,`ordem`,`id_tipo_pagamento_pedido`,id_usuario, atualizacao)
        SELECT idPedidoEntregaNovo,`valor`,DATE_FORMAT(DATE_ADD(dataFaturamentoNovo, INTERVAL prazo DAY), '%Y%m%d'),`prazo`,`ordem`,`id_tipo_pagamento_pedido`,`id_usuario`, NOW()
        FROM `webpdv`.`pedidos_compra_parcelas`
        WHERE `id_pedido_compra` = idPedidoCompra;
    */

    OPEN arrProdutos;
    SET intUltimaLinha = 0;
    Produto: LOOP
      FETCH arrProdutos
      INTO intPedidoCompraProduto;
      IF intUltimaLinha = 0
      THEN

        INSERT INTO webpdv.pedido_compra_produto
        (id_pedido_compra, id_situacao_pedido_compra_cfo, prdno, grade, unidade,
         quantidade, quantidadeRecebida, valorUnitario, tipo_frete, frete, seguro,
         desconto, outrasDespesas, bln_disponibilidade, data_entrega_cliente,
         id_usuario, atualizacao, bln_site, valorTotal)
          SELECT
            idPedidoEntregaNovo,
            id_situacao_pedido_compra_cfo,
            prdno,
            grade,
            unidade,
            quantidade,
            quantidadeRecebida,
            valorUnitario,
            tipo_frete,
            frete,
            seguro,
            desconto,
            outrasDespesas,
            bln_disponibilidade,
            data_entrega_cliente,
            id_usuario,
            NOW(),
            bln_site,
            valorTotal
          FROM webpdv.pedido_compra_produto pcp
          WHERE pcp.id_pedido_compra_produto = intPedidoCompraProduto;
        SELECT LAST_INSERT_ID()
        INTO idPedidoCompraProduto;

        INSERT INTO webpdv.pedido_compra_produto_imposto
        (id_pedido_compra_produto, CST_PIS, vBC_PIS, pPIS, vPIS, vBC_PIS_ST, pPIS_ST, vPIS_ST,
         CST_COFINS, vBC_COFINS, pCOFINS, vCOFINS, vBC_COFINS_ST, pCOFINS_ST, vCOFINS_ST,
         pIPI, vBC_IPI, vIPI,
         orig_ICMS, CST_ICMS, pICMS, pICMSRedPara, vBC_ICMS, vICMS, pICMSST, pICMSSTRedPara, vBCST_ICMS, vICMSSTRet, pMVAST_ICMS)
          SELECT
            idPedidoCompraProduto,
            CST_PIS,
            vBC_PIS,
            pPIS,
            vPIS,
            vBC_PIS_ST,
            pPIS_ST,
            vPIS_ST,
            CST_COFINS,
            vBC_COFINS,
            pCOFINS,
            vCOFINS,
            vBC_COFINS_ST,
            pCOFINS_ST,
            vCOFINS_ST,
            pIPI,
            vBC_IPI,
            vIPI,
            orig_ICMS,
            CST_ICMS,
            pICMS,
            pICMSRedPara,
            vBC_ICMS,
            vICMS,
            pICMSST,
            pICMSSTRedPara,
            vBCST_ICMS,
            vICMSSTRet,
            pMVAST_ICMS
          FROM webpdv.pedido_compra_produto_imposto
          WHERE id_pedido_compra_produto = intPedidoCompraProduto;

        INSERT INTO webpdv.pedido_compra_produto_nota
        (id_pedido_compra_produto, orig_ICMS, CST_ICMS, pICMS, pICMSRedPara, vBC_ICMS, vICMS,
         pICMSST, pICMSSTRedPara, vBCST_ICMS, vICMSST, motDesICMS,
         vBCSTRet_ICMS, vICMSSTRet, pMVAST_ICMS)
          SELECT
            idPedidoCompraProduto,
            orig_ICMS,
            CST_ICMS,
            pICMS,
            pICMSRedPara,
            vBC_ICMS,
            vICMS,
            pICMSST,
            pICMSSTRedPara,
            vBCST_ICMS,
            vICMSST,
            motDesICMS,
            vBCSTRet_ICMS,
            vICMSSTRet,
            pMVAST_ICMS
          FROM webpdv.pedido_compra_produto_nota
          WHERE id_pedido_compra_produto = intPedidoCompraProduto;
      ELSE
        LEAVE Produto;
      END IF;
    END LOOP Produto;
    CLOSE arrProdutos;

    RETURN idPedidoEntregaNovo;
  END;
