CREATE FUNCTION webpdv.produtos_entregas_pendentes_loja_atual(l_int_storeno INT, l_int_prdno INT,
                                                              l_str_grade   VARCHAR(10))
  RETURNS INT
  BEGIN
	
	DECLARE l_int_numero_produtos INT DEFAULT 0;
	DECLARE l_int_numero_produtos_busca INT;
	SELECT SUM(pedidos_entrega_produtos.qtty) INTO l_int_numero_produtos_busca 
	FROM webpdv.pedidos_entrega_produtos 
	LEFT JOIN webpdv.pedidos_entregas ON (pedidos_entrega_produtos.id_pedido_entrega = pedidos_entregas.id_pedido_entrega) 
	INNER JOIN sqlpdv.pxa 
		ON (pedidos_entregas.storeno = pxa.storeno 
			AND pedidos_entregas.ordno = pxa.eordno 
			AND pedidos_entregas.data_pedido = pxa.date
			AND pxa.bits&16 = 0)
	LEFT JOIN webpdv.lojas_central_entrega ON (pedidos_entregas.id_loja_central_entrega = lojas_central_entrega.id_loja_central_entrega)
	WHERE pedidos_entregas.storeno = l_int_storeno
    AND pedidos_entregas.storeno_estoque = l_int_storeno
	AND pedidos_entregas.id_status_entrega = 1 
	AND pedidos_entrega_produtos.prdno = l_int_prdno 
	AND pedidos_entrega_produtos.grade = l_str_grade;
	IF l_int_numero_produtos_busca > 0
	THEN 
		SET l_int_numero_produtos = l_int_numero_produtos_busca;
	END IF;
	
	RETURN(l_int_numero_produtos);
    END;
