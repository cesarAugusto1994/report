CREATE FUNCTION webpdv.montadorVerificarTipoMontagem(prestadorId INT, montagemTipoId INT)
  RETURNS TINYINT(1)
  BEGIN
	declare retorno tinyint(1);
	
	select EXISTS (
          SELECT *
          FROM webpdv.montador_tipo_montagem mtm
          WHERE mtm.prestador_id = prestadorId
              AND mtm.montagem_tipo_id = montagemTipoId
              AND mtm.ativo = 1
      ) into retorno;
      return retorno;	
    END;
