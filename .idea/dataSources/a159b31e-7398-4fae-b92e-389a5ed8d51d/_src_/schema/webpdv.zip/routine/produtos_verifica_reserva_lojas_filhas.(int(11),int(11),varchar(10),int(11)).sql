CREATE FUNCTION webpdv.produtos_verifica_reserva_lojas_filhas(storeno                     INT, prdno INT,
                                                              grade                       VARCHAR(10),
                                                              prazo_expirar_pedidos_lojas INT)
  RETURNS INT
  BEGIN
	DECLARE retorno INT DEFAULT 0;
	DECLARE ultima_linha INT DEFAULT 0;
	DECLARE storeno_filha INT DEFAULT 0;
	DECLARE storeno_neta INT DEFAULT 0;
	DECLARE estoque_filha INT DEFAULT 0;
	DECLARE estoque_neta INT DEFAULT 0;
	DECLARE quantidade_reservada INT DEFAULT 0;
	DECLARE quantidade_transferencia INT DEFAULT 0;
	DECLARE saldo_filha INT DEFAULT 0;
	DECLARE reservas_filha INT DEFAULT 0;
	DECLARE reservas_netas INT DEFAULT 0;
	DECLARE l_arr_lojas_filhas CURSOR FOR 
		SELECT lojas_estoques.storeno  
	    FROM webpdv.lojas_estoques 
	    WHERE lojas_estoques.estoque = storeno  
	    AND lojas_estoques.storeno != storeno;
	DECLARE l_arr_lojas_netas CURSOR FOR 
		SELECT lojas_estoques.storeno  
	    FROM webpdv.lojas_estoques 
	    WHERE lojas_estoques.estoque = storeno_filha  
	    AND lojas_estoques.storeno != storeno_filha;
	DECLARE CONTINUE HANDLER FOR 1329 SET ultima_linha = 1;
	
	OPEN l_arr_lojas_filhas;
	l_arr: LOOP
	SET ultima_linha = 0;
	FETCH l_arr_lojas_filhas INTO storeno_filha;
	
	IF ultima_linha >= 1
	THEN
		LEAVE l_arr;
		CLOSE l_arr_lojas_filhas;
	END IF;
		SELECT prdstk.qtty INTO estoque_filha 
	      FROM sqlpdv.prdstk 
	      WHERE prdstk.storeno = storeno_filha 
	      AND prdstk.prdno = prdno 
	      AND prdstk.grade = grade;
	INSERT INTO debug.debug SET string = CONCAT('estoque_filha ', estoque_filha);
		SELECT SUM(eoprd.qtty) INTO quantidade_reservada 
	      FROM sqldados.eord 
	      LEFT JOIN sqldados.eoprd USING (storeno, ordno)
	      WHERE eord.storeno = storeno_filha 
	      AND eord.date = DATE_FORMAT(CURRENT_DATE(), '%Y%m%d') 
	      AND eord.status = 2 
	      AND eord.auxString >= DATE_FORMAT(CURTIME() + INTERVAL prazo_expirar_pedidos_lojas HOUR_MINUTE, '%H:%i:$s') 
	      AND eoprd.prdno = prdno 
	      AND eoprd.grade = grade
	      GROUP BY eoprd.prdno, eoprd.grade;
	INSERT INTO debug.debug SET string = CONCAT('quantidade_reservada ', quantidade_reservada);
		SELECT SUM(transferencias_produtos.qtty) INTO quantidade_transferencia 
	      FROM webpdv.transferencias_produtos 
	      LEFT JOIN webpdv.transferencias USING(id_transferencia) 
	      WHERE transferencias.origem = storeno_filha 
	      AND transferencias.id_status_transferencia != 5 
	      AND transferencias_produtos.prdno = prdno 
	      AND transferencias_produtos.grade = grade
	      GROUP BY transferencias_produtos.prdno, transferencias_produtos.grade;
	INSERT INTO debug.debug SET string = CONCAT('quantidade_transferencia ', quantidade_transferencia);
		SET reservas_filha = (estoque_filha - quantidade_reservada - quantidade_transferencia);
		IF reservas_filha < 0 
		 THEN SET retorno = retorno + (reservas_filha*(-1));
		END IF;
		
		
		OPEN l_arr_lojas_netas;
			l_arr_netas: LOOP
			SET ultima_linha = 0;
			FETCH l_arr_lojas_netas INTO storeno_neta;
			IF ultima_linha >= 1
			THEN 
				LEAVE l_arr_netas;
			END IF;
				SELECT prdstk.qtty INTO estoque_neta 
			      FROM sqlpdv.prdstk 
			      WHERE prdstk.storeno = storeno_neta 
			      AND prdstk.prdno = prdno 
			      AND prdstk.grade = grade;
				SELECT SUM(eoprd.qtty) INTO quantidade_reservada 
			      FROM sqldados.eord 
			      LEFT JOIN sqldados.eoprd USING (storeno, ordno)
			      WHERE eord.storeno = storeno_neta 
			      AND eord.date = DATE_FORMAT(CURRENT_DATE(), '%Y%m%d') 
			      AND eord.status = 2 
			      AND eord.auxString >= DATE_FORMAT(CURTIME() + INTERVAL prazo_expirar_pedidos_lojas HOUR_MINUTE, '%H:%i:$s') 
			      AND eoprd.prdno = prdno 
			      AND eoprd.grade = grade
			      GROUP BY eoprd.prdno, eoprd.grade;
				SELECT SUM(transferencias_produtos.qtty) INTO quantidade_transferencia 
			      FROM webpdv.transferencias_produtos 
			      LEFT JOIN webpdv.transferencias USING(id_transferencia) 
			      WHERE transferencias.origem = storeno_neta 
			      AND transferencias.id_status_transferencia != 5 
			      AND transferencias_produtos.prdno = prdno 
			      AND transferencias_produtos.grade = grade
			      GROUP BY transferencias_produtos.prdno, transferencias_produtos.grade;
				
				SET reservas_netas = estoque_neta - quantidade_reservada - quantidade_transferencia;
				
				IF (reservas_filha < reservas_netas) && (reservas_netas < 0)
				THEN 
					SET retorno = retorno + (reservas_netas * (-1));
				END IF;
			
			END LOOP l_arr_netas;
		CLOSE l_arr_lojas_netas;
		
	
	END LOOP l_arr;
	
	RETURN retorno;
    END;
