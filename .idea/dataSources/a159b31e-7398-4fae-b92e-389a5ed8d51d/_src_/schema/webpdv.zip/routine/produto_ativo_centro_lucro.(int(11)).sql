CREATE FUNCTION webpdv.produto_ativo_centro_lucro(centroLucro INT)
  RETURNS INT
  BEGIN
	DECLARE mesInicio INT;
    DECLARE mesFim INT;
    DECLARE retorno INT;
    SELECT DATE_FORMAT( NOW(), '%Y%m' ) into mesFim;
    SELECT DATE_FORMAT( date_sub( NOW(), INTERVAL 12 MONTH), '%Y%m' ) into mesInicio;
    
    	select COUNT(*) INTO retorno
        FROM (
        SELECT pro.prdno
		from webpdv.produto pro 
		INNER JOIN webpdv.produto_movimento_mes pmm 
			ON (pmm.prdno = pro.prdno)
		inner join webpdv.produto_caracteristica pc 
			ON (pc.prdno = pmm.prdno and pc.revenda = 1)
		where pro.clno = centroLucro
		and ym between mesInicio and mesFim
        GROUP BY pro.prdno) t1;
       
    return retorno;   

RETURN 1;
END;
