CREATE FUNCTION webpdv.cria_lastno_sqlsi(l_int_storeno_origem INT, l_str_nfse CHAR(2))
  RETURNS INT
  BEGIN
	
	DECLARE l_int_lastno INT;
	
	SELECT (MAX(NO) + 1) INTO l_int_lastno 
	FROM sqlsi.lastno 
	WHERE storeno = l_int_storeno_origem 
	AND se = l_str_nfse;
    
	
	
	IF ISNULL(l_int_lastno)
		THEN
		SET l_int_lastno = 1;
	END IF;
	
	
	INSERT INTO sqlsi.lastno 
	SET NO = l_int_lastno, storeno = l_int_storeno_origem, dupse = 0, se = l_str_nfse, 
	padbyte = 'WP';
	RETURN l_int_lastno;
    END;
