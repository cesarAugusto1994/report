CREATE FUNCTION webpdv.entrega_valor_produtos(idPedidoEntrega INT)
  RETURNS INT
  BEGIN
	DECLARE valorProdutosEntrega INT;
    select SUM(IFNULL(ROUND(pep.qtty/1000 * xa2.price, 0), 0)) INTO valorProdutosEntrega
	from webpdv.pedidos_entrega_produtos pep
	LEFT JOIN webpdv.produto pro
		ON(pro.prdno_int = pep.prdno)
	LEFT JOIN webpdv.pedidos_entregas pe
		ON(pe.id_pedido_entrega = pep.id_pedido_entrega)
	LEFT JOIN sqlpdv.pxa
		ON(pxa.storeno = pe.storeno AND pxa.eordno = pe.ordno AND pxa.date = pe.data_pedido)
	LEFT JOIN sqldados.xalog2 xa2
		ON(xa2.storeno = pxa.storeno AND xa2.pdvno = pxa.pdvno AND xa2.xano = pxa.xano AND xa2.prdno = pro.prdno AND xa2.grade = pep.grade)
	where pep.id_pedido_entrega = idPedidoEntrega;
RETURN valorProdutosEntrega;
END;
