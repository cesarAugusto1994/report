CREATE FUNCTION prestadorVerificarAtivo(prestadorId INT)
  RETURNS TINYINT(1)
  BEGIN
	DECLARE retorno TINYINT;
	SELECT EXISTS(
		SELECT *
		FROM webpdv.prestador p
		WHERE p.id = prestadorId
		AND p.status = 1
		AND NOT EXISTS(
			SELECT * 
			   FROM webpdv.prestador_periodo_afastamento ppa 
			   WHERE ppa.prestador_id = p.id 
			    AND DATE_FORMAT(NOW(), '%Y%m%d') >= ppa.inicio 
			    AND DATE_FORMAT(NOW(), '%Y%m%d') <= ppa.fim 
			    AND ppa.status = 1
		)
	) INTO retorno;
	RETURN retorno;
    END;
