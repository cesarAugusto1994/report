CREATE FUNCTION gravar_log_evento(descricao VARCHAR(255))
  RETURNS TINYINT(1)
  BEGIN
	INSERT INTO webpdv.registro_eventos
		set registro = descricao, criacao = now();
    return 1;    
END;
