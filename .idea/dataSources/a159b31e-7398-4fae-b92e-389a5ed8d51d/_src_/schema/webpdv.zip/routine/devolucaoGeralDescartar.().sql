CREATE FUNCTION webpdv.devolucaoGeralDescartar()
  RETURNS INT
  BEGIN
	## busco todos os processos de devolucao geral em andamento que possam ser descartadas
    UPDATE webpdv.devolucao_geral dg
		SET dg.status = 'Descartado'
		WHERE dg.status = 'Andamento'	
		AND NOT exists(
				select *
				FROM  webpdv.devolucao_geral_pagamento dgp
				INNER JOIN webpdv.pedido_forma_pagamento pfp ON (pfp.id_pedido_forma_pagamento = dgp.id_pedido_forma_pagamento AND pfp.xatype = 3)
				WHERE dgp.id_devolucao_geral = dg.id_devolucao_geral
				AND (!ISNULL(dgp.tef_requisicao_id) )
		);
RETURN 1;
END;
