CREATE FUNCTION webpdv.valorLiquidoFormaPagamento(valorBruto      INT, taxaOperadora DECIMAL(10, 6),
                                                  taxaAntecipacao DECIMAL(10, 6), numeroParcelas INT)
  RETURNS INT
  BEGIN
  declare retorno int;
  declare valorLiquido INT;
  
  select valorBruto * (1 - (taxaOperadora/10000)) into valorLiquido;
  
  select webpdv.cartaoLiquidoAntecipacao(valorLiquido, taxaAntecipacao, numeroParcelas) into retorno;
  
  return retorno;
  
END;
