CREATE FUNCTION entregas_verifica_transacao_valida(l_int_storeno INT, l_int_ordno INT, l_str_data_pedido VARCHAR(10))
  RETURNS INT
  BEGIN
	RETURN EXISTS(
		SELECT 'X' FROM sqlpdv.pxa 
          	WHERE pxa.storeno = l_int_storeno 
          	AND pxa.eordno = l_int_ordno 
          	AND pxa.date = l_str_data_pedido);
    END;
