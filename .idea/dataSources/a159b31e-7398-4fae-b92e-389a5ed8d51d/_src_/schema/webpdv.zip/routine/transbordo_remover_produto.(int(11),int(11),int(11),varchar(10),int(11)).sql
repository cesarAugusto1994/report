CREATE FUNCTION transbordo_remover_produto(l_int_id_transbordo INT, l_int_xrouteno INT, l_int_prdno INT,
                                           l_str_grade         VARCHAR(10), l_int_qtty INT)
  RETURNS INT
  BEGIN
	DECLARE l_int_quantidade_cadastrada INT;
	
	UPDATE webpdv.transbordo_xroute_produto 
	SET qtty = qtty - l_int_qtty, qtty_entrega = qtty_entrega - l_int_qtty 
	WHERE id_transbordo = l_int_id_transbordo 
	AND xrouteno = l_int_xrouteno 
	AND prdno = l_int_prdno 
	AND grade = l_str_grade;
	
	SELECT qtty INTO l_int_quantidade_cadastrada 
	FROM webpdv.transbordo_xroute_produto 
	WHERE id_transbordo = l_int_id_transbordo 
	AND xrouteno = l_int_xrouteno 
	AND prdno = l_int_prdno 
	AND grade = l_str_grade;
	
	
	IF l_int_quantidade_cadastrada = 0 
	THEN 
		DELETE FROM webpdv.transbordo_xroute_produto 
		WHERE id_transbordo = l_int_id_transbordo 
		AND xrouteno = l_int_xrouteno 
		AND prdno = l_int_prdno 
		AND grade = l_str_grade;
	
		RETURN 0;
	ELSE
		RETURN 1;
	END IF;
	
    END;
