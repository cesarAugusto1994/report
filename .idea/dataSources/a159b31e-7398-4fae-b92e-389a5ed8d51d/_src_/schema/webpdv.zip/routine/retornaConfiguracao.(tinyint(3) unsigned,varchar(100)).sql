CREATE FUNCTION retornaConfiguracao(idGrupoTela TINYINT(3) UNSIGNED, nomeConfiguracao VARCHAR(100))
  RETURNS TEXT
  BEGIN
DECLARE valorConfiguracao TEXT;
SELECT c.valor_configuracao INTO valorConfiguracao
FROM webpdv.configuracao c
WHERE c.id_grupo_tela = idGrupoTela
AND c.nome_configuracao = nomeConfiguracao;
RETURN valorConfiguracao;
END;
