CREATE FUNCTION webpdv.montagemBuscaQtdeMontadoresLinhaEntrega(idLinhaEntrega INT, dataInicio INT, dataFim INT)
  RETURNS INT
  BEGIN
DECLARE numeroMontadores INT;
SELECT IFNULL(SUM(tm1.numeroMontadores), 0) INTO numeroMontadores
FROM (
SELECT (IFNULL(quantidade_montadores, 1) ) AS numeroMontadores
FROM webpdv.linhas_entregas_itinerarios lei2
INNER JOIN webpdv.montador_itinerario mi2 
ON ( mi2.id_entrega_itinerario = lei2.id_entrega_itinerario AND mi2.periodo_inicio <= dataInicio AND mi2.periodo_fim >= dataFim AND mi2.status = 1) 
LEFT JOIN webpdv.montador mon ON (mon.prestador_id = mi2.prestador_id)
INNER JOIN webpdv.prestador p ON (p.id = mi2.prestador_id AND p.status = 1)
LEFT JOIN webpdv.entregas_itinerarios ei2 ON (ei2.id_entrega_itinerario = mi2.id_entrega_itinerario)
WHERE lei2.id_linha_entrega = idLinhaEntrega
AND webpdv.prestadorVerificarAtivo(mi2.prestador_id) = 1
GROUP BY mon.prestador_id
) AS tm1;
RETURN numeroMontadores;
END;
