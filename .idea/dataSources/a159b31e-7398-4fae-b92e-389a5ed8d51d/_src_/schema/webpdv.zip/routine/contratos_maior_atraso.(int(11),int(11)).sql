CREATE FUNCTION contratos_maior_atraso(l_int_storeno INT, l_int_contrno INT)
  RETURNS FLOAT
  BEGIN
	DECLARE l_int_maior_atraso_parcelas FLOAT;
	
	
	
	SELECT MAX( TO_DAYS(itxa.paiddate) - TO_DAYS(itxa.duedate) ) INTO l_int_maior_atraso_parcelas 
		FROM sqldados.itxa 
		WHERE storeno = l_int_storeno 
		AND contrno = l_int_contrno 
		AND status = 1;
	RETURN l_int_maior_atraso_parcelas;
    END;
