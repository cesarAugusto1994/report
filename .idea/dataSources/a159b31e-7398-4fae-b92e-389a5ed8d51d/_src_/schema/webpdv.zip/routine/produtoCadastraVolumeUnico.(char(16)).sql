CREATE FUNCTION produtoCadastraVolumeUnico(produto CHAR(16))
  RETURNS INT
  BEGIN
	DECLARE existeCadastro TINYINT;
	SELECT EXISTS(
		SELECT *
		FROM webpdv.produtos_volumes pv
		WHERE pv.prdno = produto
	) INTO existeCadastro;
	
	INSERT INTO webpdv.produtos_volumes
	(prdno, descricao_volume, largura, altura, comprimento, peso_bruto, peso_liquido, 
		empilhamento_maximo_horizontal, empilhamento_maximo_vertical,  
		id_tipo_palete, lastro, camadas, norma_paletizacao, 
		fator_conversao, id_status_produto_volume)
	SELECT prdno, 'UNICO', 1.0, 1.0, 1.0, 1.0, 1.0, 
			1, 1, 
			1, 1, 1, 1, 
			1, 1
	FROM webpdv.produto p
	WHERE p.prdno = produto
	AND 0 = existeCadastro;
	
	RETURN 1;
	
    END;
