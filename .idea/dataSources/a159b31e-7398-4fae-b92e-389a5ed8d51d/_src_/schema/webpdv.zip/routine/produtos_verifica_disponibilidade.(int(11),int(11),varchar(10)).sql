CREATE PROCEDURE produtos_verifica_disponibilidade(IN storeno INT, IN prdno INT, IN grade VARCHAR(10))
  BEGIN
    DECLARE l_int_prdno_kit INT;
    DECLARE l_int_ultima_linha INT;
    DECLARE l_int_faixa_seguranca_busca_produtos FLOAT;
    DECLARE l_int_prazo_expirar_pedidos_lojas INT;
    DECLARE qtty_kit INT DEFAULT 0;
    DECLARE qtty_kit_minimo INT DEFAULT 0;
    DECLARE bln INT;
    DECLARE qtty INT;
    DECLARE qtty_loja INT;
    DECLARE reservas_loja INT;
    DECLARE reservas_transferencia INT;
    DECLARE desconto_transferencia INT DEFAULT 0;
    DECLARE quantidade_negativa INT DEFAULT 0;
    DECLARE quantidade_transferencia INT DEFAULT 0; 
    DECLARE storeno_mae INT DEFAULT 0;
    DECLARE storeno_avo INT DEFAULT 0;
    DECLARE bln_mae INT DEFAULT 0;
    DECLARE qtty_mae INT DEFAULT 0;
    DECLARE qtty_avo INT DEFAULT 0;
    DECLARE qtty_loja_mae INT DEFAULT 0;
    DECLARE reservas_loja_mae INT DEFAULT 0;
    DECLARE reservas_transferencia_mae INT DEFAULT 0;
    DECLARE l_arr_prdkit CURSOR FOR 
	SELECT prdkit.prdno FROM sqldados.prdkit 
	WHERE prdno_kit = prdno;
    
    DECLARE l_arr_reservas_negativos CURSOR FOR 
	SELECT prdstk.qtty*(-1), transferencias_produtos.qtty 
      FROM sqlpdv.prdstk 
      INNER JOIN webpdv.transferencias ON (transferencias.destino = prdstk.storeno AND transferencias.id_status_transferencia != 5)
      INNER JOIN webpdv.transferencias_produtos 
      	ON (transferencias.id_transferencia = transferencias_produtos.id_transferencia 
      	AND transferencias_produtos.fase = 1 
      	AND transferencias_produtos.prdno = prdstk.prdno 
      	AND transferencias_produtos.grade = prdstk.grade AND transferencias_produtos.qtty > 0) 
      WHERE prdstk.prdno = prdno 
      AND prdstk.grade = grade 
      AND transferencias.origem = storeno;
	
    DECLARE l_arr_lojas_mae CURSOR FOR 
	SELECT lojas_estoques.estoque 
	FROM webpdv.lojas_estoques 
    WHERE lojas_estoques.storeno = storeno 
    AND lojas_estoques.estoque != storeno;
    DECLARE l_arr_lojas_avo CURSOR FOR 
	SELECT lojas_estoques.estoque 
	FROM webpdv.lojas_estoques 
    WHERE lojas_estoques.storeno = storeno_mae 
    AND lojas_estoques.estoque != storeno_mae;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET l_int_ultima_linha = 1;
    
    OPEN l_arr_prdkit;
      	      SET l_int_ultima_linha = 0;
	      l_arr_prdkit: LOOP
	      FETCH l_arr_prdkit INTO l_int_prdno_kit;
	      IF l_int_ultima_linha = 0 
	      THEN 
	       CALL produtos_verifica_disponibilidade(storeno, l_int_prdno_kit, grade);
	      ELSE LEAVE l_arr_prdkit;
	      END IF;
	      END LOOP l_arr_prdkit;
      
    CLOSE l_arr_prdkit;
    SET l_int_faixa_seguranca_busca_produtos = pedidos_busca_valor_configuracao_pedidos('faixa_seguranca_busca_produtos');
    SET l_int_prazo_expirar_pedidos_lojas = pedidos_busca_valor_configuracao_pedidos('tempo_expirar_pedidos_lojas');
    
    
    SET bln = 0;
    SET qtty = 0;
    SET qtty_loja = 0;
    SET reservas_loja = 0;
    SET reservas_transferencia = 0;
    
    SELECT prdstk.qtty INTO qtty_loja 
	FROM sqlpdv.prdstk 
	WHERE prdstk.storeno = storeno 
	AND prdstk.prdno = prdno 
	AND prdstk.grade = grade;
    
    
    SELECT SUM(eoprd.qtty) INTO reservas_loja  
    FROM sqldados.eord 
    LEFT JOIN sqldados.eoprd USING (storeno, ordno)
    WHERE eord.storeno = storeno 
    AND eord.date = DATE_FORMAT(CURRENT_DATE(), '%Y%m%d') 
    AND eord.status = 2 
    AND eord.auxString >= DATE_FORMAT(CURTIME() + INTERVAL l_int_prazo_expirar_pedidos_lojas HOUR_MINUTE, '%H:%i:$s')   
    AND eoprd.prdno = prdno 
    AND eoprd.grade = grade 
    GROUP BY eoprd.prdno, eoprd.grade;
    
    SELECT SUM(transferencias_produtos.qtty) INTO reservas_transferencia 
    FROM webpdv.transferencias_produtos 
    LEFT JOIN webpdv.transferencias USING(id_transferencia) 
    WHERE 
    (
      transferencias.origem = storeno 
      AND transferencias.id_status_transferencia != 5 
      AND transferencias_produtos.prdno = prdno 
      AND transferencias_produtos.grade = grade
    )
    OR 
    (
      transferencias.destino = storeno 
      AND transferencias.id_status_transferencia = 5 
      AND transferencias.disponibilidade >= DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s')  
      AND transferencias_produtos.prdno = prdno 
      AND transferencias_produtos.grade = grade
    )
    GROUP BY transferencias_produtos.prdno, transferencias_produtos.grade;
    
    SET reservas_loja = reservas_loja + reservas_transferencia;
    
    OPEN l_arr_reservas_negativos;
      
	      SET l_int_ultima_linha = 0;
	      l_arr: LOOP
	      FETCH l_arr_reservas_negativos INTO quantidade_negativa, quantidade_transferencia;
	      
	      IF l_int_ultima_linha = 0 
	      THEN 
	        IF quantidade_negativa > quantidade_transferencia
		THEN 
		  SET reservas_loja = reservas_loja - quantidade_transferencia;
		  SET desconto_transferencia = desconto_transferencia + quantidade_transferencia;
                ELSE
		  SET reservas_loja = reservas_loja - quantidade_negativa;
		  SET desconto_transferencia = desconto_transferencia + quantidade_negativa;
	        END IF;
	      
	      ELSE LEAVE l_arr;
	      END IF; 
	      END LOOP l_arr;
      
    CLOSE l_arr_reservas_negativos;
    
    SET reservas_loja = reservas_loja + produtos_verifica_reserva_lojas_filhas(storeno, prdno, grade, l_int_prazo_expirar_pedidos_lojas);
    
    SET qtty = qtty_loja - reservas_loja + desconto_transferencia;
    
    OPEN l_arr_lojas_mae;
	l_arr: LOOP
	SET l_int_ultima_linha = 0;
	FETCH l_arr_lojas_mae INTO storeno_mae;
	IF l_int_ultima_linha = 0 
		THEN SET qtty_mae = produtos_verifica_disponibilidade(storeno_mae, prdno, grade);
		IF qtty_mae > 0
			THEN SET qtty = qtty + qtty_mae;
		END IF;
	ELSE LEAVE l_arr;
	END IF;
	
	OPEN l_arr_lojas_avo;
		l_arr_avo: LOOP
		SET l_int_ultima_linha = 0;
		FETCH l_arr_lojas_avo INTO storeno_avo;
		IF l_int_ultima_linha = 0
			THEN 
				SET qtty_avo = produtos_verifica_disponibilidade(storeno_avo, prdno, grade);
				IF qtty_avo > 0
					THEN SET qtty = qtty + qtty_avo;
				END IF;
			ELSE LEAVE l_arr_avo;
		END IF;
		END LOOP l_arr_avo;
	CLOSE l_arr_lojas_avo;
	
	END LOOP l_arr;
    CLOSE l_arr_lojas_mae;
    
    IF qtty > 0 
	THEN SET bln = 1;
    ELSEIF qtty_loja > 0
	THEN SET bln = 1;
    END IF;
    SELECT bln, qtty, qtty_loja, reservas_loja, reservas_transferencia;
END;
