CREATE FUNCTION webpdv.estoque_atualiza_custo_medio(int_storeno INT, str_prdno VARCHAR(16))
  RETURNS INT
  BEGIN
	DECLARE int_custo INT DEFAULT 0;
	DECLARE int_custo_calculado INT DEFAULT 0;
	
	
	SELECT ROUND(cm_varejo/100) INTO int_custo
	FROM sqlsi.stk
	WHERE stk.storeno = int_storeno
	AND stk.prdno = str_prdno
	LIMIT 1;
	
	
	SELECT webpdv.estoque_calcula_custo_medio(int_storeno, str_prdno) INTO int_custo_calculado;
	
	SELECT IFNULL(int_custo_calculado, int_custo) INTO int_custo_calculado;
	
	UPDATE sqlsi.stk
	SET cm_varejo = int_custo_calculado*100, cm_real = int_custo_calculado*100
	WHERE stk.storeno = int_storeno
	AND stk.prdno = str_prdno;
	
	RETURN int_custo_calculado;
    END;
