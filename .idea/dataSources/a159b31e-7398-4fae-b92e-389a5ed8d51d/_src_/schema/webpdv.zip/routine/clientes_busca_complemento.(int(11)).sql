CREATE FUNCTION clientes_busca_complemento(custno INT)
  RETURNS INT
  BEGIN
	DECLARE complemento_retorno TEXT;
	SELECT complemento INTO complemento_retorno
	FROM webpdv.complementos_clientes 
	WHERE complementos_clientes.custno = custno;
	RETURN complemento_retorno;
    END;
