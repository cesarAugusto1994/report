CREATE FUNCTION clientes_cria_novo_cadastro_saci(l_str_cpf VARCHAR(18), l_int_storeno INT)
  RETURNS INT
  BEGIN
        DECLARE l_int_custno INT;

        SELECT MAX(custp.no)+1 INTO l_int_custno FROM sqldados.custp;
        INSERT INTO sqldados.custp 
                SET NO = l_int_custno, cpf_cgc = l_str_cpf, sincedt = DATE_FORMAT(CURDATE(), '%Y%m%d'), 
                storeno = l_int_storeno, fjflag = 1, crlimit = 0, 
                dtcrlimit = DATE_FORMAT(CURDATE(), '%Y%m%d');
        INSERT INTO sqlsi.custp 
                SET NO = l_int_custno, cpf_cgc = l_str_cpf, sincedt = DATE_FORMAT(CURDATE(), '%Y%m%d'), 
                storeno = l_int_storeno, fjflag = 1, crlimit = 0, 
                dtcrlimit = DATE_FORMAT(CURDATE(), '%Y%m%d');

        RETURN l_int_custno;
  END;
