CREATE FUNCTION transferencias_busca_data_ultima_fase2(l_int_xrouteno INT)
  RETURNS VARCHAR(10)
  BEGIN
	DECLARE l_str_data_retorno VARCHAR(10);	
	SELECT (
		SELECT data_transferencia  
		FROM webpdv.transferencias 
		LEFT JOIN webpdv.transferencias_produtos 
			ON (transferencias.id_transferencia = transferencias_produtos.id_transferencia 
				AND transferencias_produtos.fase = 2 AND transferencias_produtos.qtty > 0)
		WHERE transferencias.xrouteno = l_int_xrouteno
		AND !ISNULL(transferencias_produtos.id_transferencia_produto)
		AND transferencias.id_status_transferencia = 5 
		AND transferencias.data_transferencia > DATE_FORMAT( DATE_SUB( CURDATE(), INTERVAL 15 DAY ) ,"%Y%m%d") 
		GROUP BY transferencias.id_transferencia 
		
		UNION 
		
		SELECT DATE_FORMAT( DATE_SUB( CURDATE(), INTERVAL 15 DAY ) ,"%Y%m%d") as data_transferencia 
		
		ORDER BY data_transferencia DESC 
		LIMIT 1)
		INTO l_str_data_retorno;
	
	return l_str_data_retorno;    END;
