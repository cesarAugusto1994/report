CREATE PROCEDURE nota_fiscal_excluir(IN notaFiscalId INT)
  BEGIN
	DELETE FROM webpdv.nota_fiscal_prod
	WHERE nota_fiscal_id = notaFiscalId;
	DELETE FROM webpdv.nota_fiscal_emit
	WHERE nota_fiscal_id = notaFiscalId;
	DELETE FROM webpdv.nota_fiscal_dest
	WHERE nota_fiscal_id = notaFiscalId;
	DELETE FROM webpdv.nota_fiscal_total
	WHERE nota_fiscal_id = notaFiscalId;
	DELETE FROM webpdv.nota_fiscal_cob
	WHERE nota_fiscal_id = notaFiscalId;
	DELETE FROM webpdv.nota_fiscal_cob_dup
	WHERE nota_fiscal_id = notaFiscalId;
	DELETE FROM webpdv.nota_fiscal_desdob
	WHERE nota_fiscal_id = notaFiscalId;
	DELETE FROM webpdv.nota_fiscal_log
	WHERE nota_fiscal_id = notaFiscalId;
	DELETE FROM webpdv.nota_fiscal_transporte
	WHERE nota_fiscal_id = notaFiscalId;
	DELETE FROM webpdv.nota_fiscal_transporte_reboque
	WHERE nota_fiscal_id = notaFiscalId;
	DELETE FROM webpdv.nota_fiscal_transporte_volume
	WHERE nota_fiscal_id = notaFiscalId;
	
	DELETE FROM webpdv.nota_fiscal_inf
	WHERE nota_fiscal_id = notaFiscalId;
	
	DELETE FROM webpdv.nota_fiscal_xml
	WHERE nota_fiscal_id = notaFiscalId;
	
	DELETE FROM webpdv.emissor_lote_nota
	WHERE nota_fiscal_id = notaFiscalId;
	
	DELETE FROM webpdv.nota_fiscal_forma_pgto
	where nota_fiscal_id = notaFiscalId;
	
	DELETE FROM webpdv.nota_fiscal
	WHERE id = notaFiscalId;
	
    END;
