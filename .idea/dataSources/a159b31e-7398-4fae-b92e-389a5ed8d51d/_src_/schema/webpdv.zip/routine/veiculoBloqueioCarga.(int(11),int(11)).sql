CREATE FUNCTION webpdv.veiculoBloqueioCarga(idVeiculo INT, centralEntrega INT)
  RETURNS VARCHAR(255)
  BEGIN
	DECLARE diasBloqueio INT;
	DECLARE dataCorte INT;
	
	
	SELECT dias_bloqueio_criar_carga_veiculo INTO diasBloqueio
	FROM webpdv.centrais_entrega
	WHERE storeno = centralEntrega;
	
	IF(0 = diasBloqueio)
	THEN
		RETURN '0';
	END IF;
	
	SELECT DATE_FORMAT( DATE_SUB(current_date, INTERVAL diasBloqueio DAY), '%Y%m%d' ) INTO dataCorte;
	
	RETURN webpdv.veiculoBloqueioCargaData(idVeiculo, centralEntrega, dataCorte);
	
    END;
