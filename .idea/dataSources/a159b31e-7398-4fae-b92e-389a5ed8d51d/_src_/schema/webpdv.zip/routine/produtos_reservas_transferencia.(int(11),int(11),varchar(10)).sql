CREATE FUNCTION webpdv.produtos_reservas_transferencia(l_int_storeno INT, l_int_prdno INT, l_str_grade VARCHAR(10))
  RETURNS INT
  BEGIN
	DECLARE l_int_qtty INT;
	SELECT SUM(tp.qtty) INTO l_int_qtty 
		FROM webpdv.transferencias_produtos tp 
		LEFT JOIN webpdv.transferencias t ON (tp.id_transferencia = t.id_transferencia) 
		WHERE t.origem = l_int_storeno 
		AND t.id_status_transferencia != 5 
		AND tp.prdno = l_int_prdno
		AND tp.grade = l_str_grade;
	RETURN l_int_qtty;
    END;
