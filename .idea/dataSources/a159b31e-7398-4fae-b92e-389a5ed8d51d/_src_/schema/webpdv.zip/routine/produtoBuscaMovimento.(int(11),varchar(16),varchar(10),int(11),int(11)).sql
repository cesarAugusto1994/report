CREATE FUNCTION produtoBuscaMovimento(l_storeno INT, l_prdno VARCHAR(16), l_grade VARCHAR(10), l_dataInicio INT,
                                      l_dataFim INT)
  RETURNS INT
  BEGIN
	DECLARE retorno INT;
	SELECT 0 INTO retorno;
	SELECT IFNULL(SUM(entrada), 0) - IFNULL(SUM(saida), 0) INTO retorno
	FROM (
		SELECT iprd.storeno, iprd.prdno, iprd.grade, SUM(iprd.qtty) AS entrada, 0 AS saida
		FROM sqldados.iprd
		LEFT JOIN sqldados.inv USING(invno)
		WHERE iprd.storeno = l_storeno
		AND iprd.prdno = l_prdno
		AND iprd.grade = l_grade
		AND iprd.date BETWEEN l_dataInicio AND l_dataFim
		AND inv.bits&16 = 0
		GROUP BY iprd.storeno, iprd.prdno, iprd.grade
		
		UNION ALL
		
		SELECT xaprd.storeno, xaprd.prdno, xaprd.grade, 0 AS entrada, SUM(xaprd.qtty*1000) AS saida
		FROM sqldados.xaprd
		LEFT JOIN sqldados.nf USING (storeno, pdvno, xano)
		WHERE xaprd.storeno = l_storeno
		AND xaprd.prdno = l_prdno
		AND xaprd.grade = l_grade
		AND xaprd.date BETWEEN l_dataInicio AND l_dataFim
		AND nf.status = 0
		AND NOT EXISTS(SELECT 'x' FROM sqlpdv.pxa WHERE pxa.storeno = nf.storeno AND pxa.pdvno = nf.pdvno AND pxa.xano = nf.xano)
		GROUP BY xaprd.storeno, xaprd.prdno, xaprd.grade
		
		# Volto a ter a movimentacao de cliente
		UNION ALL
		
		SELECT xalog2.storeno, xalog2.prdno, xalog2.grade, 0 AS entrada, SUM(xalog2.qtty) AS saida
		FROM sqldados.xalog2
		WHERE xalog2.storeno = l_storeno
		AND xalog2.prdno = l_prdno
		AND xalog2.grade = l_grade
		AND xalog2.date BETWEEN l_dataInicio AND l_dataFim
		AND xalog2.qtty > 0
		GROUP BY xalog2.storeno, xalog2.prdno, xalog2.grade
		
		UNION ALL
		
		SELECT xedprd.storeno, xedprd.prdno, xedprd.grade,
		SUM(IF(qtty > 0, qtty, 0)) AS entrada,
		SUM(IF(qtty < 0, (-1)*qtty, 0)) AS saida
		FROM sqldados.xedprd
		WHERE xedprd.storeno = l_storeno
		AND xedprd.prdno = l_prdno
		AND xedprd.grade = l_grade
		AND xedprd.date BETWEEN l_dataInicio AND l_dataFim
		GROUP BY xedprd.storeno, xedprd.prdno, xedprd.grade
		
		UNION ALL
		
		SELECT storeno, prdno, grade,
	        SUM(IF(qtty > 0, qtty, 0)) AS entrada,
	        SUM(IF(qtty < 0, (-1)*qtty, 0)) AS saida
		FROM sqldados.stkmov
		WHERE 1=1
		AND stkmov.storeno = l_storeno
		AND stkmov.prdno = l_prdno
		AND stkmov.grade = l_grade
		AND DATE BETWEEN l_dataInicio AND l_dataFim
		GROUP BY storeno, prdno, grade
		
		UNION ALL
		
		# TROCA
		SELECT xalog2.storeno, xalog2.prdno, xalog2.grade, SUM(xalog2.qtty)*(-1) AS entrada,
		  0 AS saida
		FROM sqldados.xalog2
			INNER JOIN sqlpdv.pxa ON (xalog2.storeno = pxa.storeno AND xalog2.pdvno = pxa.pdvno AND xalog2.xano = pxa.xano)
		WHERE xalog2.storeno = l_storeno
		AND xalog2.prdno = l_prdno
		AND xalog2.grade = l_grade
		AND xalog2.date BETWEEN l_dataInicio AND l_dataFim
		AND qtty < 0
		GROUP BY storeno, prdno, grade
	) AS qttyFinal
	GROUP BY storeno, prdno, grade;
	
	RETURN retorno;
    END;
