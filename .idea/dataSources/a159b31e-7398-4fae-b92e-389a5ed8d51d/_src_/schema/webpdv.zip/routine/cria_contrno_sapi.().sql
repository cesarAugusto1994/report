CREATE FUNCTION cria_contrno_sapi()
  RETURNS INT
  BEGIN
    
    DECLARE l_int_contrno INT;
    
    SELECT (MAX(contrno) + 1) INTO l_int_contrno
    FROM sapi.inst 
    WHERE storeno = 1;
    
    
    
    IF ISNULL(l_int_contrno)
        THEN
        SET l_int_contrno = 1;
    END IF;
    
    
    INSERT INTO sapi.inst
    SET storeno = 1, contrno = l_int_contrno;
    RETURN l_int_contrno;
    END;
