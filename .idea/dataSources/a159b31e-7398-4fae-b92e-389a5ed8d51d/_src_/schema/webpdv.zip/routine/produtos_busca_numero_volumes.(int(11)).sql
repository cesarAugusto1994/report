CREATE FUNCTION webpdv.produtos_busca_numero_volumes(prdno INT)
  RETURNS INT
  BEGIN
	DECLARE numero_volumes INT;
	SELECT COUNT(produtos_volumes.id_produto_volume) INTO numero_volumes 
	FROM produtos_volumes 
	WHERE produtos_volumes.prdno = prdno 
	AND id_status_produto_volume = 1;
	RETURN numero_volumes;
    END;
