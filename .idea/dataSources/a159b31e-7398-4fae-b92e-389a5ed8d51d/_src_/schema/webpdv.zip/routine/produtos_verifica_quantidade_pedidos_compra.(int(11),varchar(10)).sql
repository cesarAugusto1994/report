CREATE FUNCTION produtos_verifica_quantidade_pedidos_compra(prdno INT, grade VARCHAR(10))
  RETURNS INT
  BEGIN
	DECLARE quantidade INT;
	
	SELECT SUM(oprd.qtty) INTO quantidade 
	FROM sqldados.oprd 
	LEFT JOIN sqldados.ords ON (oprd.storeno = ords.storeno AND oprd.ordno = ords.no)
	WHERE ords.status = 0 
	AND dataEntrega >= DATE_FORMAT(CURRENT_DATE(), '%Y%m%d')
	AND oprd.prdno = prdno 
	AND oprd.grade = grade;
	
	RETURN quantidade;
    END;
