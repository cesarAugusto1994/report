CREATE FUNCTION webpdv.usuario_busca_hora_extra(idUsuario INT, Data INT)
  RETURNS VARCHAR(5)
  BEGIN
	declare horarioExtra varchar(10);
    
    select IFNULL( (select MAX(horario_limite) 
	FROM webpdv.horario_extra he
	where he.id_usuario = idUsuario
	AND data_inicio <= Data
	and data_fim >= Data
    AND he.status = 1
    ), 
		(select MAX(horario_limite) 
	FROM webpdv.usuarios u 
    INNER JOIN webpdv.horario_extra he
		ON (he.storeno = u.id_usuario)
	where u.id_usuario = idUsuario
    AND he.id_usuario = 0
	AND data_inicio <= Data
	and data_fim >= Data
    AND he.status = 1
    ) ) into horarioExtra;
	
    
    return horarioExtra;
    
RETURN 1;
END;
