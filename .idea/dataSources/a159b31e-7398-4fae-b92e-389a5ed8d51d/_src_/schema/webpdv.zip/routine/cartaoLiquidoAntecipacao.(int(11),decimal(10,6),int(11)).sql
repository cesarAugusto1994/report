CREATE FUNCTION webpdv.cartaoLiquidoAntecipacao(valorBruto INT, taxaAntecipacao DECIMAL(10, 6), numeroParcelas INT)
  RETURNS INT
  BEGIN
  declare parcelaAtual decimal;
  declare numeroParcelasRecorrente int;
  declare retorno int;
  
  select 0 into retorno;
  
  #select valorBruto * pow(taxaAntecipacao, numeroParcelas) into parcelaAtual;
  select valorBruto * (1 - ((1 - taxaAntecipacao) * numeroParcelas) ) into parcelaAtual;
  
  select retorno + parcelaAtual into retorno;
  
  WHILE numeroParcelas > 1 DO
	select numeroParcelas - 1 into numeroParcelas;
    select valorBruto * (1 - ((1 - taxaAntecipacao) * numeroParcelas) ) into parcelaAtual;
    select retorno + parcelaAtual into retorno;
  END WHILE;
  
  return retorno;
  
END;
