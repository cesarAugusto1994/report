CREATE FUNCTION webpdv.notas_recebimento_busca_numero(intStoreno SMALLINT(6), strPrdno CHAR(16), strGrade CHAR(10),
                                                      dataLimite DATE)
  RETURNS CHAR(100)
  BEGIN
	DECLARE retorno char(100);
    SELECT '' INTO retorno;
    select group_concat(t3.numero_notas) into retorno
	from (
	   select nf2.nNF as numero_notas, nfp2.prdno, nfp2.grade
		from webpdv.nota_fiscal nf2
		inner join webpdv.nota_fiscal_prod nfp2 ON (nfp2.nota_fiscal_id = nf2.id)
		where nf2.storeno = intStoreno
			AND nf2.tipoEmissao = 'Terceiro'
			AND nf2.emissor_status_nf_id = 14
			AND nf2.dSaiEnt <= dataLimite
			AND nfp2.prdno = strPrdno
			AND nfp2.grade = strGrade
		order by nf2.dSaiEnt desc
		LIMIT 1
		) t3
	;
RETURN retorno;
END;
