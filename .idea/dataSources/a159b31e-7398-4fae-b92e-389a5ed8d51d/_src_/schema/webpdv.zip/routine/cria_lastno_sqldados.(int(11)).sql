CREATE FUNCTION webpdv.cria_lastno_sqldados(l_int_storeno_origem INT)
  RETURNS INT
  BEGIN
	
	DECLARE l_int_lastno INT;
	
	SELECT (MAX(NO) + 1) INTO l_int_lastno 
	FROM sqldados.lastno 
	WHERE storeno = l_int_storeno_origem 
	AND se = '1 ';
    
	
	
	IF ISNULL(l_int_lastno)
		THEN
		SET l_int_lastno = 1;
	END IF;
	
	
	INSERT INTO sqldados.lastno 
	SET NO = l_int_lastno, storeno = l_int_storeno_origem, dupse = 0, se = '1 ', 
	padbyte = '  ';
	RETURN l_int_lastno;
    END;
