CREATE FUNCTION webpdv.cria_numeracao_por_tipo(str_tipo VARCHAR(20))
  RETURNS INT
  BEGIN
    DECLARE int_numero INT;

    SELECT (MAX(`numero`)+1) INTO int_numero
    FROM `webpdv`.`numeracao_por_tipo`
    WHERE `tipo` = str_tipo
    ;

    IF ISNULL(int_numero)
    THEN
      SET int_numero = 1;
    END IF;

    INSERT INTO `webpdv`.`numeracao_por_tipo` SET
      `tipo` = str_tipo,
      `numero` = int_numero;

    RETURN int_numero;
  END;
