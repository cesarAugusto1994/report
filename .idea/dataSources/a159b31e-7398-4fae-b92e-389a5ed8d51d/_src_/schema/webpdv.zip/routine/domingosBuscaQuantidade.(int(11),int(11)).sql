CREATE FUNCTION domingosBuscaQuantidade(intDataInicio INT, intDataFim INT)
  RETURNS INT
  BEGIN
	DECLARE numeroDias INT;
	DECLARE numeroDomingos INT;
	DECLARE controle INT;
	
	SELECT 0 INTO controle;
	SELECT 0 INTO numeroDomingos;
	SELECT DATEDIFF(intDataFim, intDataInicio) + 1 INTO numeroDias;
	WHILE controle < numeroDias DO
		## Caso dia da semana seja domingo
		IF  DAYOFWEEK(  ADDDATE( DATE_FORMAT( intDataInicio, '%Y-%m-%d' ), INTERVAL controle DAY ) ) = 1 THEN
			SELECT numeroDomingos + 1 INTO numeroDomingos;
		END IF;
		SET controle = controle + 1;
	END WHILE;
	
	RETURN numeroDomingos;
	
    END;
