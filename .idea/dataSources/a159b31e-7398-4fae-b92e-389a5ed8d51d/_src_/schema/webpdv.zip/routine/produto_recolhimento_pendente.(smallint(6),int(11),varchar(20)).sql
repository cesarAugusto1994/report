CREATE FUNCTION webpdv.produto_recolhimento_pendente(Storeno SMALLINT(6), Prdno INT, Grade VARCHAR(20))
  RETURNS INT
  BEGIN
	declare qttyRecolhimento INT;
    select 0 INTO qttyRecolhimento;
	SELECT IFNULL(SUM(rmp.qtty), 0) INTO qttyRecolhimento
	FROM webpdv.recolhimento_mercadorias rm
	LEFT JOIN webpdv.recolhimento_mercadorias_produtos rmp
	  ON (rmp.id_recolhimento_mercadoria = rm.id_recolhimento_mercadoria)
	WHERE rm.storeno = Storeno
	  AND rm.id_status_recolhimento_mercadoria IN (1, 2, 4) # Pendente, Em Andamento, Tentar Novamente
	  AND rmp.prdno = Prdno
	  AND rmp.grade = Grade
      AND rm.bln_reserva_mercadoria = 1;
RETURN qttyRecolhimento;
END;
