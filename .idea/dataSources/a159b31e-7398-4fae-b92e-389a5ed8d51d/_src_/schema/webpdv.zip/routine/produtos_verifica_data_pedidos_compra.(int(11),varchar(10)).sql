CREATE FUNCTION produtos_verifica_data_pedidos_compra(prdno INT, grade VARCHAR(10))
  RETURNS VARCHAR(10)
  BEGIN
	DECLARE data VARCHAR(10);
	
	SELECT ords.dataEntrega INTO data 
	FROM sqldados.oprd 
	LEFT JOIN sqldados.ords ON (oprd.storeno = ords.storeno AND oprd.ordno = ords.no)
	WHERE ords.status = 0 
	AND dataEntrega >= DATE_FORMAT(CURRENT_DATE(), '%Y%m%d')
	AND oprd.prdno = prdno 
	AND oprd.grade = grade;
	
	RETURN data;
    END;
