CREATE FUNCTION webpdv.checar_forma_atendimento_disponivel(storeno INT, id_forma_atendimento INT)
  RETURNS TINYINT(1)
  BEGIN
    DECLARE qtde_registros_filial INT;
    DECLARE qtde_registros_tipo_fililal INT;
    DECLARE forma_atendimento_habilitada BOOL;
    DECLARE empresa_id INT;
    DECLARE filial_tipo_id INT;

    SELECT COUNT(*)
    INTO qtde_registros_filial
    FROM webpdv.filial_forma_atendimento ffa
    WHERE ffa.ativo = 1
      AND ffa.storeno = storeno;

    IF 0 < qtde_registros_filial
    THEN
      SELECT EXISTS(
          SELECT 'x'
          FROM webpdv.filial_forma_atendimento ffa
          WHERE ffa.ativo = 1
                AND ffa.storeno = storeno
                AND ffa.id_forma_atendimento = id_forma_atendimento
      )
      INTO forma_atendimento_habilitada;
      RETURN forma_atendimento_habilitada;
    END IF;

    SELECT
      ef.empresa_id,
      ef.filial_tipo_id
    INTO empresa_id, filial_tipo_id
    FROM webpdv.empresa_filial ef
    WHERE ef.storeno = storeno;

    SELECT COUNT(*)
    INTO qtde_registros_tipo_fililal
    FROM webpdv.filial_forma_atendimento ffa
    WHERE ffa.ativo = 1
          AND ffa.filial_tipo_id = filial_tipo_id;

    IF 0 < qtde_registros_tipo_fililal
    THEN

      SELECT EXISTS(
          SELECT 'x'
          FROM webpdv.filial_forma_atendimento ffa
          WHERE ffa.ativo = 1
                AND ffa.filial_tipo_id = filial_tipo_id
                AND ffa.id_forma_atendimento = id_forma_atendimento
      )
      INTO forma_atendimento_habilitada;

      RETURN forma_atendimento_habilitada;

    END IF;

    SELECT EXISTS(
        SELECT 'x'
        FROM webpdv.filial_forma_atendimento ffa
        WHERE ffa.ativo = 1
              AND ffa.empresa_id = empresa_id
              AND ffa.id_forma_atendimento = id_forma_atendimento
    )
    INTO forma_atendimento_habilitada;

    RETURN forma_atendimento_habilitada;

  END;
