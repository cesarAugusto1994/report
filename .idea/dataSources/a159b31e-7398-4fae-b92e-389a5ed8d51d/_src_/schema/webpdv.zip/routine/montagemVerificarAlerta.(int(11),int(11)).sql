CREATE FUNCTION montagemVerificarAlerta(idPedidoEntrega INT, prazoConsiderarAlerta INT)
  RETURNS TINYINT(1)
  BEGIN
    DECLARE retorno BOOLEAN;
    # MONTAGEM ALERTA
    SELECT IF(webpdv.montagemVerificarAtraso(idPedidoEntrega) = 1,
              0,
              IF(0 < m.data_agendamento, IF(MIN(m.data_agendamento) <= DATE_FORMAT(NOW(), '%Y-%m-%d'), 1, 0),
                 IF(0 < pe.data_agendamento_montagem,
                    IF(DATE_SUB(DATE_FORMAT(pe.data_agendamento_montagem, '%Y-%m-%d'), INTERVAL prazoConsiderarAlerta /*DIAS CONSIDERAR ALERTA*/ DAY) <= DATE_FORMAT(NOW(), '%Y-%m-%d'), 1, 0),
                    IF(DATE_SUB(DATE_FORMAT(pe.previsao_montagem, '%Y-%m-%d'), INTERVAL prazoConsiderarAlerta /*DIAS CONSIDERAR ALERTA*/ DAY) <= DATE_FORMAT(NOW(), '%Y-%m-%d'), 1, 0)
                 )
              ))
    INTO retorno
    FROM webpdv.pedidos_entregas pe
      LEFT JOIN webpdv.montagens m ON (m.id_origem = pe.id_pedido_entrega AND m.tipo = 'ENTREGA')
    WHERE id_pedido_entrega = idPedidoEntrega;
    RETURN retorno;
  END;
