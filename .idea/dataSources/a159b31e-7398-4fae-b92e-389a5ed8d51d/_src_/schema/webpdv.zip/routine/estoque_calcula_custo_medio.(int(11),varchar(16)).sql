CREATE FUNCTION webpdv.estoque_calcula_custo_medio(int_storeno INT, str_prdno VARCHAR(16))
  RETURNS INT
  BEGIN
	DECLARE int_custo INT DEFAULT 0;
	SELECT ROUND(SUM(iprd.qtty * iprd.cost) / SUM(iprd.qtty)) INTO int_custo
		FROM sqlsi.iprd
		WHERE storeno = int_storeno
		AND prdno = str_prdno;
	RETURN int_custo;
    END;
