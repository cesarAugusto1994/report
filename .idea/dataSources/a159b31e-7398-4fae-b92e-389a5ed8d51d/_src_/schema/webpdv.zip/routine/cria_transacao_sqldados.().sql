CREATE FUNCTION webpdv.cria_transacao_sqldados()
  RETURNS INT
  BEGIN
	DECLARE l_int_xano INT;
	INSERT INTO sqldados.xa SET xano = '';
	SELECT LAST_INSERT_ID() INTO l_int_xano;
	RETURN  l_int_xano;
    END;
