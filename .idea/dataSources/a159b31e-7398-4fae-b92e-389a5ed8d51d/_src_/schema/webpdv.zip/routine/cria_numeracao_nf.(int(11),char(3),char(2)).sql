CREATE FUNCTION webpdv.cria_numeracao_nf(int_storeno INT, str_serie CHAR(3), str_modelo CHAR(2))
  RETURNS INT
  BEGIN
    DECLARE int_numero INT;

    SELECT (MAX(`numero`)+1) INTO int_numero
    FROM `webpdv`.`nota_fiscal_numeracao`
    WHERE `storeno` = int_storeno
          AND `serie` = str_serie
          AND `modelo` = str_modelo
    ;

    IF ISNULL(int_numero)
    THEN
      SET int_numero = 1;
    END IF;

    INSERT INTO `webpdv`.`nota_fiscal_numeracao` SET
      `storeno` = int_storeno,
      `serie` = str_serie,
      `modelo` = str_modelo,
      `numero` = int_numero;

    RETURN int_numero;
  END;
