CREATE FUNCTION produtos_disponibilidade_transbordo_mostruario(l_int_storeno INT, l_int_prdno INT,
                                                               l_str_grade   VARCHAR(10))
  RETURNS INT
  BEGIN
	DECLARE l_int_disponibilidade INT DEFAULT 0;
	DECLARE l_int_temp INT DEFAULT 0;
	
	SELECT qtty INTO l_int_disponibilidade
	FROM sqlpdv.prdstk 
	WHERE storeno = l_int_storeno
	AND prdno = l_int_prdno 
	AND grade = l_str_grade;
	
	SELECT IF(SUM(pep.qtty) >0, SUM(pep.qtty), 0) INTO l_int_temp
		FROM webpdv.pedidos_entregas pe
		LEFT JOIN webpdv.pedidos_entrega_produtos pep ON (pep.id_pedido_entrega = pe.id_pedido_entrega) 
		LEFT JOIN webpdv.lojas_central_entrega lce ON (pe.id_loja_central_entrega = lce.id_loja_central_entrega)
		WHERE webpdv.entregas_verifica_transacao_valida(pe.storeno, pe.ordno, pe.data_pedido)
		AND lce.central_entrega = l_int_storeno
		AND pe.id_status_entrega = 1 
		AND (
			pe.estoque = 1 
			OR 
			(pe.data_entrega != '0000-00-00 00:00:00' AND pe.data_entrega <= CONCAT(DATE_FORMAT( CURRENT_DATE(), '%y-%m-%d' ), ' 00:00:00' ) )
		)
		AND pep.prdno = l_int_prdno 
		AND pep.grade = l_str_grade;
	
	SET l_int_disponibilidade = l_int_disponibilidade - l_int_temp;
	
	
	SET l_int_temp = 0;
	SELECT IF(SUM(pep.qtty) >0, SUM(pep.qtty), 0) INTO l_int_temp
		FROM webpdv.pedidos_entregas pe
		LEFT JOIN webpdv.pedidos_entrega_produtos pep ON (pep.id_pedido_entrega = pe.id_pedido_entrega) 
		LEFT JOIN webpdv.lojas_central_entrega lce ON (pe.id_loja_central_entrega = lce.id_loja_central_entrega)
		WHERE webpdv.entregas_verifica_transacao_valida(pe.storeno, pe.ordno, pe.data_pedido)
		AND lce.central_entrega IN (
			SELECT le.storeno 
			FROM webpdv.lojas_estoques le
			WHERE le.estoque = l_int_storeno
			)
		AND lce.id_pedido_entrega_tipo = 1
		AND pe.id_status_entrega = 1 
		AND (
			pe.estoque = 1 
			OR 
			(pe.data_entrega != '0000-00-00 00:00:00' AND pe.data_entrega <= CONCAT(DATE_FORMAT( CURRENT_DATE(), '%y-%m-%d' ), ' 00:00:00' ) )
		)
		AND pep.prdno = l_int_prdno 
		AND pep.grade = l_str_grade;
	
	SET l_int_disponibilidade = l_int_disponibilidade - l_int_temp;
	
	RETURN l_int_disponibilidade;
    END;
