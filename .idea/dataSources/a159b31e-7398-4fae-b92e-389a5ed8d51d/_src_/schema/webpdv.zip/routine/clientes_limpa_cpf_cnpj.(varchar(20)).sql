CREATE FUNCTION webpdv.clientes_limpa_cpf_cnpj(l_str_cpf_cnpj VARCHAR(20))
  RETURNS VARCHAR(14)
  BEGIN
	RETURN REPLACE( REPLACE(l_str_cpf_cnpj, '.', ''), '-', '' );
    END;
