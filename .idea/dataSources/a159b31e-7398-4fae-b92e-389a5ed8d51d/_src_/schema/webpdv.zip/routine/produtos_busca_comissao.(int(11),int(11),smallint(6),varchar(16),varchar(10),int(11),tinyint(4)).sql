CREATE FUNCTION produtos_busca_comissao(empresa_id      INT, empresa_tipo_comissionamento_id INT, storeno SMALLINT(6),
                                        prdno           VARCHAR(16), grade VARCHAR(10), data_venda INT,
                                        interno_externo TINYINT)
  RETURNS INT
  BEGIN
	DECLARE comissao_interna INT;
	DECLARE comissao_externa INT;
	DECLARE encontrou TINYINT;
	DECLARE comissionamento_por_filial TINYINT;
	DECLARE typeno SMALLINT;
	DECLARE clno INT;
	DECLARE requer_montagem TINYINT;
	DECLARE empresa_filial_id INT;
    DECLARE gera_comissao TINYINT;
    
    SELECT 0 INTO encontrou;
	## definir typeno e clno e se produto requer montagem
	SELECT p.typeno INTO typeno
	FROM webpdv.produto p
	WHERE p.prdno = prdno;
    
    SELECT tp.gera_comissao INTO gera_comissao
    FROM webpdv.tipo_produto tp
    WHERE tp.typeno = typeno;
    
    IF gera_comissao = 0
		THEN return 0.00;
    END IF;    
    
    SELECT p.clno INTO clno
	FROM webpdv.produto p
	WHERE p.prdno = prdno;
	
	SELECT IF(pc.nao_requer_montagem = 1, 0, 1) INTO requer_montagem
	FROM webpdv.produto_caracteristica pc
	WHERE pc.prdno = prdno;
	## definir empresa_filial_id
	SELECT ef.id INTO empresa_filial_id
	FROM webpdv.empresa_filial ef
	WHERE ef.storeno = storeno;
    
    ## comissao por produto - detalhado
	IF EXISTS(SELECT *
		FROM webpdv.produto_comissao pco 
		    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = storeno 
		    AND pco.prdno = prdno 
		    AND pco.grade = grade 
		    AND pco.todas_grades = 0 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1) = 1
	   THEN 
	    SET encontrou = 1;
	    
            SELECT pco.comissao INTO comissao_interna
	    FROM webpdv.produto_comissao pco 
	    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = storeno 
		    AND pco.prdno = prdno 
		    AND pco.grade = grade 
		    AND pco.todas_grades = 0 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1;
		    
	    SELECT pco.comissao_func_externo INTO comissao_externa
	    FROM webpdv.produto_comissao pco 
	    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = storeno 
		    AND pco.prdno = prdno 
		    AND pco.grade = grade 
		    AND pco.todas_grades = 0 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1;
	    
	END IF;
        
        IF(1 = encontrou)
          THEN 
		RETURN IF(interno_externo = 1, comissao_interna, comissao_externa);
	END IF;
        
	## comissao por produto - todas grades
	IF EXISTS(SELECT *
		FROM webpdv.produto_comissao pco 
		    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = storeno 
		    AND pco.prdno = prdno 
		    AND pco.todas_grades = 1 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1) = 1
	   THEN 
	    SET encontrou = 1;
	    
            SELECT comissao INTO comissao_interna
	    FROM webpdv.produto_comissao pco 
	    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = storeno 
		    AND pco.prdno = prdno 
		    AND pco.todas_grades = 1 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1;
	    SELECT comissao_func_externo INTO comissao_externa
	    FROM webpdv.produto_comissao pco 
	    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = storeno 
		    AND pco.prdno = prdno 
		    AND pco.todas_grades = 1 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1;
	    
	END IF;
        
        IF(1 = encontrou)
          THEN 
		RETURN IF(interno_externo = 1, comissao_interna, comissao_externa);
	END IF;
	
	## comissao por produto - todas as lojas - detalhado
	IF EXISTS(SELECT *
		FROM webpdv.produto_comissao pco 
		    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = 0 
		    AND pco.prdno = prdno 
		    AND pco.grade = grade 
		    AND pco.todas_grades = 0 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1) = 1
	   THEN 
	    SET encontrou = 1;
	    
            SELECT comissao INTO comissao_interna
	    FROM webpdv.produto_comissao pco 
	    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = 0 
		    AND pco.prdno = prdno 
		    AND pco.grade = grade 
		    AND pco.todas_grades = 0 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1;
	    SELECT comissao_func_externo INTO comissao_externa
	    FROM webpdv.produto_comissao pco 
	    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = 0 
		    AND pco.prdno = prdno 
		    AND pco.grade = grade 
		    AND pco.todas_grades = 0 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1;
	END IF;
        
        IF(1 = encontrou)
          THEN 
		RETURN IF(interno_externo = 1, comissao_interna, comissao_externa);
	END IF;
	
	## comissao por produto - todas as lojas - todas as grades
	IF EXISTS(SELECT *
		FROM webpdv.produto_comissao pco 
		    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = 0 
		    AND pco.prdno = prdno 
		    AND pco.todas_grades = 1 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1) = 1
	   THEN 
	    SET encontrou = 1;
            SELECT comissao INTO comissao_interna
	    FROM webpdv.produto_comissao pco 
	    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = 0 
		    AND pco.prdno = prdno 
		    AND pco.todas_grades = 1 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1;
	    SELECT comissao_func_externo INTO comissao_externa
	    FROM webpdv.produto_comissao pco 
	    WHERE pco.empresa_id = empresa_id 
		    AND pco.storeno = 0 
		    AND pco.prdno = prdno 
		    AND pco.todas_grades = 1 
		    AND pco.validade_inicio <= data_venda 
		    AND pco.validade_fim >= data_venda 
		    AND pco.status = 1;
	END IF;
        
        IF(1 = encontrou)
          THEN 
		RETURN IF(interno_externo = 1, comissao_interna, comissao_externa);
	END IF;
	
	## verifico se tipo de comissionamento é por empresa ou filial
	SELECT usa_comissionamento_filial INTO comissionamento_por_filial
	FROM webpdv.empresa_tipo_comissionamento etc
	WHERE etc.id = empresa_tipo_comissionamento_id;
	
	## Comissao por filial... tabela empresa_filial_valor_comissionamento
	IF(1 = comissionamento_por_filial)
	THEN
		IF(EXISTS(SELECT *
			FROM webpdv.empresa_filial_valor_comissionamento efvc
			WHERE efvc.empresa_filial_id = empresa_filial_id
			AND efvc.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
			AND efvc.tipo = 'clno' 
			AND efvc.clno = clno 
			AND efvc.validade_inicio <= data_venda 
			AND efvc.validade_fim >= data_venda 
			AND efvc.status = 1) = 1)
		THEN 
			IF(requer_montagem = 1)
			THEN
				SELECT comissao_com_montagem INTO comissao_interna
				FROM webpdv.empresa_filial_valor_comissionamento efvc
				WHERE efvc.empresa_filial_id = empresa_filial_id
				AND efvc.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND efvc.tipo = 'clno' 
				AND efvc.clno = clno 
				AND efvc.validade_inicio <= data_venda 
				AND efvc.validade_fim >= data_venda 
				AND efvc.status = 1;
				SELECT comissao_com_montagem_func_externo INTO comissao_externa
				FROM webpdv.empresa_filial_valor_comissionamento efvc
				WHERE efvc.empresa_filial_id = empresa_filial_id
				AND efvc.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND efvc.tipo = 'clno' 
				AND efvc.clno = clno 
				AND efvc.validade_inicio <= data_venda 
				AND efvc.validade_fim >= data_venda 
				AND efvc.status = 1;
			ELSE
				SELECT comissao_sem_montagem INTO comissao_interna
				FROM webpdv.empresa_filial_valor_comissionamento efvc
				WHERE efvc.empresa_filial_id = empresa_filial_id
				AND efvc.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND efvc.tipo = 'clno' 
				AND efvc.clno = clno 
				AND efvc.validade_inicio <= data_venda 
				AND efvc.validade_fim >= data_venda 
				AND efvc.status = 1;
				SELECT comissao_sem_montagem_func_externo INTO comissao_externa
				FROM webpdv.empresa_filial_valor_comissionamento efvc
				WHERE efvc.empresa_filial_id = empresa_filial_id
				AND efvc.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND efvc.tipo = 'clno' 
				AND efvc.clno = clno 
				AND efvc.validade_inicio <= data_venda 
				AND efvc.validade_fim >= data_venda 
				AND efvc.status = 1;
			END IF;
		ELSE
			IF(requer_montagem = 1)
			THEN
				SELECT comissao_com_montagem INTO comissao_interna
				FROM webpdv.empresa_filial_valor_comissionamento efvc
				WHERE efvc.empresa_filial_id = empresa_filial_id
				AND efvc.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND efvc.tipo = 'typeno' 
				AND efvc.typeno = typeno 
				AND efvc.validade_inicio <= data_venda 
				AND efvc.validade_fim >= data_venda 
				AND efvc.status = 1;
				SELECT comissao_com_montagem_func_externo INTO comissao_externa
				FROM webpdv.empresa_filial_valor_comissionamento efvc
				WHERE efvc.empresa_filial_id = empresa_filial_id
				AND efvc.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND efvc.tipo = 'typeno' 
				AND efvc.typeno = typeno 
				AND efvc.validade_inicio <= data_venda 
				AND efvc.validade_fim >= data_venda 
				AND efvc.status = 1;
			ELSE
				SELECT comissao_sem_montagem INTO comissao_interna
				FROM webpdv.empresa_filial_valor_comissionamento efvc
				WHERE efvc.empresa_filial_id = empresa_filial_id
				AND efvc.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND efvc.tipo = 'typeno' 
				AND efvc.typeno = typeno 
				AND efvc.validade_inicio <= data_venda 
				AND efvc.validade_fim >= data_venda 
				AND efvc.status = 1;
				SELECT comissao_sem_montagem_func_externo INTO comissao_externa
				FROM webpdv.empresa_filial_valor_comissionamento efvc
				WHERE efvc.empresa_filial_id = empresa_filial_id
				AND efvc.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND efvc.tipo = 'typeno' 
				AND efvc.typeno = typeno 
				AND efvc.validade_inicio <= data_venda 
				AND efvc.validade_fim >= data_venda 
				AND efvc.status = 1;
			END IF;
		END IF;
	ELSE
	## Comissao por empresa
		IF( EXISTS(SELECT *
		FROM webpdv.empresa_tipo_comissionamento_valor etcv
		WHERE etcv.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
		AND etcv.tipo = 'clno' 
		AND etcv.clno = clno 
		AND etcv.validade_inicio <= data_venda 
		AND etcv.validade_fim >= data_venda 
		AND etcv.status = 1) = 1 )
		THEN
			IF(requer_montagem = 1)
			THEN
				SELECT comissao_com_montagem INTO comissao_interna
				FROM webpdv.empresa_tipo_comissionamento_valor etcv
				WHERE etcv.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND etcv.tipo = 'clno' 
				AND etcv.clno = clno 
				AND etcv.validade_inicio <= data_venda 
				AND etcv.validade_fim >= data_venda 
				AND etcv.status = 1;
				SELECT comissao_com_montagem_func_externo INTO comissao_externa
				FROM webpdv.empresa_tipo_comissionamento_valor etcv
				WHERE etcv.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND etcv.tipo = 'clno' 
				AND etcv.clno = clno 
				AND etcv.validade_inicio <= data_venda 
				AND etcv.validade_fim >= data_venda 
				AND etcv.status = 1;
			ELSE
				SELECT comissao_sem_montagem INTO comissao_interna
				FROM webpdv.empresa_tipo_comissionamento_valor etcv
				WHERE etcv.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND etcv.tipo = 'clno' 
				AND etcv.clno = clno 
				AND etcv.validade_inicio <= data_venda 
				AND etcv.validade_fim >= data_venda 
				AND etcv.status = 1;
				SELECT comissao_sem_montagem_func_externo INTO comissao_externa
				FROM webpdv.empresa_tipo_comissionamento_valor etcv
				WHERE etcv.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND etcv.tipo = 'clno' 
				AND etcv.clno = clno 
				AND etcv.validade_inicio <= data_venda 
				AND etcv.validade_fim >= data_venda 
				AND etcv.status = 1;
			END IF;
		ELSE
			IF(requer_montagem = 1)
			THEN
				SELECT comissao_com_montagem INTO comissao_interna
				FROM webpdv.empresa_tipo_comissionamento_valor etcv
				WHERE etcv.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND etcv.tipo = 'typeno' 
				AND etcv.typeno = typeno 
				AND etcv.validade_inicio <= data_venda 
				AND etcv.validade_fim >= data_venda 
				AND etcv.status = 1;
				SELECT comissao_com_montagem_func_externo INTO comissao_externa
				FROM webpdv.empresa_tipo_comissionamento_valor etcv
				WHERE etcv.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND etcv.tipo = 'typeno' 
				AND etcv.typeno = typeno 
				AND etcv.validade_inicio <= data_venda 
				AND etcv.validade_fim >= data_venda 
				AND etcv.status = 1;
			ELSE
				SELECT comissao_sem_montagem INTO comissao_interna
				FROM webpdv.empresa_tipo_comissionamento_valor etcv
				WHERE etcv.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND etcv.tipo = 'typeno' 
				AND etcv.typeno = typeno 
				AND etcv.validade_inicio <= data_venda 
				AND etcv.validade_fim >= data_venda 
				AND etcv.status = 1;
				SELECT comissao_sem_montagem_func_externo INTO comissao_externa
				FROM webpdv.empresa_tipo_comissionamento_valor etcv
				WHERE etcv.empresa_tipo_comissionamento_id = empresa_tipo_comissionamento_id 
				AND etcv.tipo = 'typeno' 
				AND etcv.typeno = typeno 
				AND etcv.validade_inicio <= data_venda 
				AND etcv.validade_fim >= data_venda 
				AND etcv.status = 1;
			END IF;
		END IF;
		
	END IF;
	
	IF(interno_externo = 1)
	THEN RETURN comissao_interna;
	ELSE RETURN comissao_externa;
	END IF;
	
    END;
