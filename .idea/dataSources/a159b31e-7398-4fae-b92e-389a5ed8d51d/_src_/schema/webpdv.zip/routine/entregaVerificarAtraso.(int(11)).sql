CREATE FUNCTION entregaVerificarAtraso(idPedidoEntrega INT)
  RETURNS TINYINT(1)
  BEGIN
	DECLARE retorno BOOLEAN;
	# ATRASO
	SELECT 
	IF(
		( (0 < pe.agendamento_entrega) AND (pe.agendamento_entrega > DATE_FORMAT(NOW(), '%Y%m%d') ) ) 
		OR 
		((0 < pe.data_entrega) AND (pe.data_entrega >= DATE_FORMAT(NOW(), '%Y-%m-%d') )),
	 0, 
	 
	 IF(DATE_FORMAT(NOW(), '%Y%m%d') <= pe.previsao_entrega,
	  0, 
	  1
	 )
	) INTO retorno
	FROM webpdv.pedidos_entregas pe
	WHERE id_pedido_entrega = idPedidoEntrega;
	
	RETURN retorno;
    END;
