CREATE FUNCTION webpdv.transbordo_adicionar_produto(l_int_id_transbordo INT, l_int_xrouteno INT, l_int_prdno INT,
                                                    l_str_grade         VARCHAR(10), l_int_qtty INT)
  RETURNS INT
  BEGIN
	DECLARE l_bln_verifica_produto BOOLEAN;
	
	SELECT EXISTS(
		SELECT 'X' 
		FROM webpdv.transbordo_xroute_produto 
		WHERE id_transbordo = l_int_id_transbordo 
		AND xrouteno = l_int_xrouteno 
		AND prdno = l_int_prdno 
		AND grade = l_str_grade
		) INTO l_bln_verifica_produto;
	IF l_bln_verifica_produto  
	THEN 
		UPDATE webpdv.transbordo_xroute_produto 
		SET qtty = qtty + l_int_qtty, qtty_entrega = qtty_entrega + l_int_qtty  
		WHERE id_transbordo = l_int_id_transbordo 
		AND xrouteno = l_int_xrouteno 
		AND prdno = l_int_prdno 
		AND grade = l_str_grade;
	ELSE
		INSERT INTO webpdv.transbordo_xroute_produto 
		SET id_transbordo = l_int_id_transbordo, 
		xrouteno = l_int_xrouteno, prdno = l_int_prdno, 
		grade = l_str_grade, qtty = l_int_qtty, qtty_entrega = l_int_qtty;
	END IF;
	RETURN 1;
    END;
