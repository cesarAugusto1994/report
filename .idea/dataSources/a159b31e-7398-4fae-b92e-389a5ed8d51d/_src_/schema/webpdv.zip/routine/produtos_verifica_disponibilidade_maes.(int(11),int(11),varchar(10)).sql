CREATE FUNCTION webpdv.produtos_verifica_disponibilidade_maes(storeno INT, prdno INT, grade VARCHAR(10))
  RETURNS INT
  BEGIN
	DECLARE l_int_prdno_kit INT;
	DECLARE ultima_linha INT DEFAULT 0;
	DECLARE l_int_faixa_seguranca_busca_produtos FLOAT;
	DECLARE l_int_prazo_expirar_pedidos_lojas INT;
	DECLARE qtty INT DEFAULT 0;
	DECLARE qtty_loja_mae INT DEFAULT 0;
	DECLARE reservas_loja_mae INT DEFAULT 0;
	DECLARE reservas_transferencia_mae INT DEFAULT 0;
	
	DECLARE quantidade_negativa_mae INT;
	DECLARE quantidade_transferencia_mae INT;
	DECLARE desconto_transferencia_mae INT;
	DECLARE qtty_loja_avo INT DEFAULT 0;
	DECLARE reservas_loja_avo INT DEFAULT 0;
	DECLARE reservas_transferencia_avo INT DEFAULT 0;
	
	DECLARE quantidade_negativa_avo INT;
	DECLARE quantidade_transferencia_avo INT;
	DECLARE desconto_transferencia_avo INT;
	DECLARE storeno_mae INT;
	DECLARE storeno_avo INT;
	DECLARE l_arr_lojas_mae CURSOR FOR 
		SELECT lojas_estoques.estoque 
		FROM webpdv.lojas_estoques 
		WHERE lojas_estoques.storeno = storeno 
		AND lojas_estoques.estoque != storeno;
	DECLARE l_arr_lojas_avo CURSOR FOR 
		SELECT lojas_estoques.estoque 
		FROM webpdv.lojas_estoques 
		WHERE lojas_estoques.storeno = storeno_mae 
		AND lojas_estoques.estoque != storeno_mae;
	
	DECLARE l_arr_reservas_negativos_mae CURSOR FOR 
		SELECT prdstk.qtty*(-1), transferencias_produtos.qtty 
		FROM sqlpdv.prdstk 
		INNER JOIN webpdv.transferencias ON (transferencias.destino = prdstk.storeno AND transferencias.id_status_transferencia != 5)
		INNER JOIN webpdv.transferencias_produtos 
		ON (transferencias.id_transferencia = transferencias_produtos.id_transferencia 
		AND transferencias_produtos.fase = 1 
		AND transferencias_produtos.prdno = prdstk.prdno 
		AND transferencias_produtos.grade = prdstk.grade AND transferencias_produtos.qtty > 0) 
		WHERE prdstk.prdno = prdno 
		AND prdstk.grade = grade 
		AND transferencias.origem = storeno_mae;
	DECLARE l_arr_reservas_negativos_avo CURSOR FOR 
		SELECT prdstk.qtty*(-1), transferencias_produtos.qtty 
		FROM sqlpdv.prdstk 
		INNER JOIN webpdv.transferencias ON (transferencias.destino = prdstk.storeno AND transferencias.id_status_transferencia != 5)
		INNER JOIN webpdv.transferencias_produtos 
		ON (transferencias.id_transferencia = transferencias_produtos.id_transferencia 
		AND transferencias_produtos.fase = 1 
		AND transferencias_produtos.prdno = prdstk.prdno 
		AND transferencias_produtos.grade = prdstk.grade AND transferencias_produtos.qtty > 0) 
		WHERE prdstk.prdno = prdno 
		AND prdstk.grade = grade 
		AND transferencias.origem = storeno_avo;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET ultima_linha = 1;
	SET l_int_faixa_seguranca_busca_produtos = pedidos_busca_valor_configuracao_pedidos('faixa_seguranca_busca_produtos');
	SET l_int_prazo_expirar_pedidos_lojas = pedidos_busca_valor_configuracao_pedidos('tempo_expirar_pedidos_lojas');
	
	
	OPEN l_arr_lojas_mae;
		SET ultima_linha = 0;
		l_arr_mae: LOOP
		FETCH l_arr_lojas_mae INTO storeno_mae;
		IF ultima_linha = 0
		THEN 
			
			SELECT prdstk.qtty INTO qtty_loja_mae 
			FROM sqlpdv.prdstk 
			WHERE prdstk.storeno = storeno_mae 
			AND prdstk.prdno = prdno 
			AND prdstk.grade = grade;
			
			SELECT SUM(eoprd.qtty) INTO reservas_loja_mae  
			FROM sqldados.eord 
			LEFT JOIN sqldados.eoprd USING (storeno, ordno)
			WHERE eord.storeno = storeno_mae 
			AND eord.date = DATE_FORMAT(CURRENT_DATE(), '%Y%m%d') 
			AND eord.status = 2 
			AND eord.auxString >= DATE_FORMAT(CURTIME() + INTERVAL l_int_prazo_expirar_pedidos_lojas HOUR_MINUTE, '%H:%i:$s')   
			AND eoprd.prdno = prdno 
			AND eoprd.grade = grade 
			GROUP BY eoprd.prdno, eoprd.grade;
			
			SELECT SUM(transferencias_produtos.qtty) INTO reservas_transferencia_mae 
			FROM webpdv.transferencias_produtos 
			LEFT JOIN webpdv.transferencias USING(id_transferencia) 
			WHERE 
			(
			transferencias.origem = storeno_mae 
			AND transferencias.id_status_transferencia != 5 
			AND transferencias_produtos.prdno = prdno 
			AND transferencias_produtos.grade = grade
			)
			OR 
			(
			transferencias.destino = storeno_mae 
			AND transferencias.id_status_transferencia = 5 
			AND transferencias.disponibilidade >= DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s')  
			AND transferencias_produtos.prdno = prdno 
			AND transferencias_produtos.grade = grade
			)
			GROUP BY transferencias_produtos.prdno, transferencias_produtos.grade;
			
			SET reservas_loja_mae = reservas_loja_mae + reservas_transferencia_mae;
			
			IF storeno_mae = 1
			THEN
			
			OPEN l_arr_reservas_negativos_mae;
			      SET ultima_linha = 0;
			      l_arr: LOOP
			      FETCH l_arr_reservas_negativos_mae INTO quantidade_negativa_mae, quantidade_transferencia_mae;
			      
			      IF ultima_linha = 0 
			      THEN 
				IF quantidade_negativa_mae > quantidade_transferencia_mae
				THEN 
				  SET reservas_loja_mae = reservas_loja_mae - quantidade_transferencia_mae;
				  SET desconto_transferencia_mae = desconto_transferencia_mae + quantidade_transferencia_mae;
				ELSE
				  SET reservas_loja_mae = reservas_loja_mae - quantidade_negativa_mae;
				  SET desconto_transferencia_mae = desconto_transferencia_mae + quantidade_negativa_mae;
				END IF;
			      
			      ELSE LEAVE l_arr;
			      END IF; 
			      END LOOP l_arr;
			CLOSE l_arr_reservas_negativos_mae;
			END IF;
			
			SET reservas_loja_mae = reservas_loja_mae + produtos_verifica_reserva_lojas_filhas(storeno_mae, prdno, grade, l_int_prazo_expirar_pedidos_lojas);
			
			
			IF reservas_loja_mae < qtty_loja_mae
			THEN 
				SET qtty = qtty + qtty_loja_mae - reservas_loja_mae;
			END IF;
			IF storeno_mae != 1
			THEN 
			OPEN l_arr_lojas_avo;
				SET ultima_linha = 0;
				l_arr_avo: LOOP
				FETCH l_arr_lojas_avo INTO storeno_avo;
				IF ultima_linha = 0
				THEN
					IF storeno_avo = 1
					THEN 
					
					SELECT prdstk.qtty INTO qtty_loja_avo 
					FROM sqlpdv.prdstk 
					WHERE prdstk.storeno = storeno_avo 
					AND prdstk.prdno = prdno 
					AND prdstk.grade = grade;
					
					SELECT SUM(eoprd.qtty) INTO reservas_loja_avo  
					FROM sqldados.eord 
					LEFT JOIN sqldados.eoprd USING (storeno, ordno)
					WHERE eord.storeno = storeno_avo 
					AND eord.date = DATE_FORMAT(CURRENT_DATE(), '%Y%m%d') 
					AND eord.status = 2 
					AND eord.auxString >= DATE_FORMAT(CURTIME() + INTERVAL l_int_prazo_expirar_pedidos_lojas HOUR_MINUTE, '%H:%i:$s')   
					AND eoprd.prdno = prdno 
					AND eoprd.grade = grade 
					GROUP BY eoprd.prdno, eoprd.grade;
					
					SELECT SUM(transferencias_produtos.qtty) INTO reservas_transferencia_avo 
					FROM webpdv.transferencias_produtos 
					LEFT JOIN webpdv.transferencias USING(id_transferencia) 
					WHERE 
					(
					transferencias.origem = storeno_avo 
					AND transferencias.id_status_transferencia != 5 
					AND transferencias_produtos.prdno = prdno 
					AND transferencias_produtos.grade = grade
					)
					OR 
					(
					transferencias.destino = storeno_avo 
					AND transferencias.id_status_transferencia = 5 
					AND transferencias.disponibilidade >= DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s')  
					AND transferencias_produtos.prdno = prdno 
					AND transferencias_produtos.grade = grade
					)
					GROUP BY transferencias_produtos.prdno, transferencias_produtos.grade;
					
					SET reservas_loja_avo = reservas_loja_avo + reservas_transferencia_avo;
					
					OPEN l_arr_reservas_negativos_avo;
					      SET ultima_linha = 0;
					      l_arr: LOOP
					      FETCH l_arr_reservas_negativos_avo INTO quantidade_negativa_avo, quantidade_transferencia_avo;
					      
					      IF ultima_linha = 0 
					      THEN 
						IF quantidade_negativa_avo > quantidade_transferencia_avo
						THEN 
						  SET reservas_loja_avo = reservas_loja_avo - quantidade_transferencia_avo;
						  SET desconto_transferencia_avo = desconto_transferencia_avo + quantidade_transferencia_avo;
						ELSE
						  SET reservas_loja_avo = reservas_loja_avo - quantidade_negativa_avo;
						  SET desconto_transferencia_avo = desconto_transferencia_avo + quantidade_negativa_avo;
						END IF;
					      
					      ELSE LEAVE l_arr;
					      END IF; 
					      END LOOP l_arr;
					CLOSE l_arr_reservas_negativos_avo;
					
					SET reservas_loja_avo = reservas_loja_avo + produtos_verifica_reserva_lojas_filhas(storeno_avo, prdno, grade, l_int_prazo_expirar_pedidos_lojas);
					
					IF reservas_loja_avo < qtty_loja_avo
					THEN 
						SET qtty = qtty + qtty_loja_avo - reservas_loja_avo;
					END IF;
					END IF;
				ELSE LEAVE l_arr_avo;
				END IF;
				END LOOP l_arr_avo;
			CLOSE l_arr_lojas_avo;
			END IF;
		ELSE LEAVE l_arr_mae;
		END IF;
		END LOOP l_arr_mae;
	CLOSE l_arr_lojas_mae;
	
	RETURN(qtty);
    END;
