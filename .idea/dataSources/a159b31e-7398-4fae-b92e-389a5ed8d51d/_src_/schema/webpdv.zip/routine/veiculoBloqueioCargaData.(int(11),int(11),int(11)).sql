CREATE FUNCTION veiculoBloqueioCargaData(idVeiculo INT, centralEntrega INT, dataCorte INT)
  RETURNS VARCHAR(255)
  BEGIN
	DECLARE retorno VARCHAR(255);
	
	SELECT EXISTS (
		 SELECT ca.id_veiculo
		 FROM webpdv.cargas ca
		 WHERE ca.id_veiculo = idVeiculo
		  AND ca.data_finalizacao <= dataCorte
		  AND ca.central_entrega = centralEntrega
		  AND id_status_carga = 2 /*finalizada*/
		  AND EXISTS (
		   SELECT * 
		   FROM webpdv.cargas_entregas_vinculadas cev 
		   INNER JOIN webpdv.pedido_entrega_custo pec ON (pec.id_pedido_entrega = cev.id_pedido_entrega)
		   INNER JOIN webpdv.pedidos_entregas pe ON (pe.id_pedido_entrega = pec.id_pedido_entrega)
		   WHERE cev.id_carga = ca.id_carga
            AND cev.bln_corte = 0
		    AND pec.status = 'EmAndamento'
		    AND pe.id_status_entrega = 4
		 )
	) INTO retorno;
	
	IF('1' = retorno)
	THEN 
		SELECT GROUP_CONCAT(ca.id_carga) AS carga
		 FROM webpdv.cargas ca
		 WHERE ca.id_veiculo = idVeiculo
		  AND ca.data_finalizacao <= dataCorte
		  AND ca.central_entrega = centralEntrega
		  AND id_status_carga = 2 /*finalizada*/
		  AND EXISTS (
		   SELECT * 
		   FROM webpdv.cargas_entregas_vinculadas cev 
		   INNER JOIN webpdv.pedido_entrega_custo pec ON (pec.id_pedido_entrega = cev.id_pedido_entrega)
		   INNER JOIN webpdv.pedidos_entregas pe ON (pe.id_pedido_entrega = pec.id_pedido_entrega)
		   WHERE cev.id_carga = ca.id_carga
            AND cev.bln_corte = 0
		    AND pec.status = 'EmAndamento'
		    AND pe.id_status_entrega = 4
		 )
		 GROUP BY ca.id_veiculo INTO retorno;
		 RETURN retorno;
	END IF;	
	
	RETURN retorno;
    END;
