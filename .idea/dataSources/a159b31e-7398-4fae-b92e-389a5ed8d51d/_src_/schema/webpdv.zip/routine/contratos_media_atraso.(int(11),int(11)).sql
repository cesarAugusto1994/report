CREATE FUNCTION webpdv.contratos_media_atraso(l_int_storeno INT, l_int_contrno INT)
  RETURNS FLOAT
  BEGIN
	DECLARE l_int_media_atraso_parcelas FLOAT;
	
	
	SELECT AVG( TO_DAYS(itxa.paiddate) - TO_DAYS(itxa.duedate) ) INTO l_int_media_atraso_parcelas 
		FROM sqldados.itxa 
		WHERE storeno = l_int_storeno 
		AND contrno = l_int_contrno 
		AND (
			(status = 1)
			OR 
			(status IN (0, 2, 3) AND itxa.duedate < DATE_FORMAT(CURDATE(), '%Y%m%d'))
		);
	RETURN l_int_media_atraso_parcelas; 
    END;
