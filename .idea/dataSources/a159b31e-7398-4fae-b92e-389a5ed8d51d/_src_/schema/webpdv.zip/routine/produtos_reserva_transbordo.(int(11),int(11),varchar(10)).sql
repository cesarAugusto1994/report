CREATE FUNCTION webpdv.produtos_reserva_transbordo(l_int_storeno INT, l_int_prdno INT, l_str_grade VARCHAR(10))
  RETURNS INT
  BEGIN
	DECLARE l_int_qtty INT DEFAULT 0;
	DECLARE l_int_temp INT DEFAULT 0;
	
	
	SELECT SUM(tp.qtty) INTO l_int_temp 
	FROM webpdv.transferencias t 
	INNER JOIN webpdv.transferencias_produtos tp ON (t.id_transferencia = tp.id_transferencia)
	WHERE t.id_status_transferencia = 5 
	AND t.disponibilidade > CONCAT(CURRENT_DATE(), ' ', CURRENT_TIME()) 
	AND t.destino = l_int_storeno
	AND tp.prdno = l_int_prdno 
	AND tp.grade = l_str_grade;
	
	IF !ISNULL(l_int_temp)
	THEN 
		SET l_int_qtty = l_int_qtty + l_int_temp;
	END IF;
	SET l_int_temp = 0;
	
	SELECT SUM(tp.qtty) INTO l_int_temp
	FROM webpdv.transbordo_xroute tx
	INNER JOIN webpdv.transbordo_xroute_produto tp ON (tx.id_transbordo = tp.id_transbordo AND tx.xrouteno = tp.xrouteno)
	INNER JOIN sqldados.xroute ON (tx.xrouteno = xroute.no)
	WHERE tx.disponibilidade > CONCAT(CURRENT_DATE(), ' ', CURRENT_TIME()) 
	AND xroute.storenoTo = l_int_storeno
	AND tp.prdno = l_int_prdno 
	AND tp.grade = l_str_grade;
	
	IF !ISNULL(l_int_temp)
	THEN 
		SET l_int_qtty = l_int_qtty + l_int_temp;
	END IF;
	
	RETURN l_int_qtty;
    END;
