CREATE FUNCTION produtos_busca_peso(l_int_prdno CHAR(16))
  RETURNS FLOAT
  BEGIN
	DECLARE peso_produto FLOAT;
	DECLARE numero_itens_kit INT;
	SELECT COUNT(*) INTO numero_itens_kit
	FROM sqldados.prdkit
	WHERE prdno_kit = l_int_prdno;
	
	IF(numero_itens_kit > 0)
	THEN
		SELECT ROUND(SUM( (pv.peso_bruto) ), 5) INTO peso_produto
		FROM sqldados.prdkit
		LEFT JOIN webpdv.produtos_volumes pv ON (pv.prdno = prdkit.prdno)
		WHERE prdkit.prdno_kit = l_int_prdno
		GROUP BY prdkit.prdno_kit;
	ELSE	
		SELECT SUM(peso_bruto) INTO peso_produto 
		FROM produtos_volumes 
		WHERE produtos_volumes.prdno = l_int_prdno 
		AND id_status_produto_volume = 1;
		
	END IF;
	RETURN peso_produto;
	
END;
