CREATE FUNCTION webpdv.feriadosBuscaQuantidade(intDataInicio INT, intDataFim INT, intStoreno SMALLINT(6))
  RETURNS INT
  BEGIN
	DECLARE numeroFeriados INT;
	DECLARE strDataInicioFixa VARCHAR(10);
	DECLARE strDataFimFixa VARCHAR(10);
	
	SELECT CONCAT('0000', MID(intDataInicio, 5, 4) ) INTO strDataInicioFixa; 
	SELECT CONCAT('0000', MID(intDataFim, 5, 4) ) INTO strDataFimFixa;
	
	SELECT IFNULL(COUNT(*), 0) INTO numeroFeriados
	FROM (
	 SELECT f1.data
	 FROM (
	  SELECT *
	  FROM webpdv.feriado fa
	  WHERE fa.data BETWEEN intDataInicio AND intDataFim
	  AND fa.tipo = 'Variavel'
	  AND fa.storeno = intStoreno
	  AND fa.id_status = 1
	  UNION
	  SELECT *
	  FROM webpdv.feriado fe
	  WHERE fe.data BETWEEN intDataInicio AND intDataFim
	  AND fe.tipo = 'Variavel'
	  AND fe.storeno = 0
	  AND fe.id_status = 1
	  UNION
	  SELECT *
	  FROM webpdv.feriado fa
	  WHERE fa.data BETWEEN strDataInicioFixa AND strDataFimFixa
	  AND fa.tipo = 'Fixo'
	  AND fa.storeno = intStoreno
	  AND fa.id_status = 1
	  UNION
	  SELECT *
	  FROM webpdv.feriado fe
	  WHERE fe.data BETWEEN strDataInicioFixa AND strDataFimFixa
	  AND fe.tipo = 'Fixo'
	  AND fe.storeno = 0
	  AND fe.id_status = 1
	 ) f1
	 GROUP BY MID(f1.data, 5, 4)
	) t2;
	
	
	RETURN (numeroFeriados + webpdv.domingosBuscaQuantidade(intDataInicio, intDataFim) );
    END;
