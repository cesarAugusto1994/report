CREATE FUNCTION produto_cadastra_movimento_mes(intStoreno SMALLINT(6), strPrdno CHAR(16), strGrade VARCHAR(10))
  RETURNS TINYINT(1)
  BEGIN
	DECLARE mes INT;
	DECLARE existe INT;
		
	SELECT DATE_FORMAT(NOW(), '%Y%m') INTO mes;
	
	SELECT EXISTS(
		SELECT *
		FROM webpdv.produto_movimento_mes pmm
		WHERE pmm.storeno = intStoreno
		AND pmm.prdno = strPrdno
		AND pmm.grade = strGrade 
	) INTO existe;
	
	IF existe = 0
	THEN
		INSERT INTO webpdv.produto_movimento_mes
		SET storeno = intStoreno, prdno = strPrdno, grade = strGrade, ym = mes;
		
		INSERT INTO webpdv.produto_movimento_mes_registro
		SET storeno = intStoreno, prdno = strPrdno, grade = strGrade, ym = mes, criacao = NOW();
		
		RETURN TRUE;
		
	END IF;
	
	RETURN FALSE;
    END;
