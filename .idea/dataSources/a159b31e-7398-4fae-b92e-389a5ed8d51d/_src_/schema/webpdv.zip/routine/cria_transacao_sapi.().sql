CREATE FUNCTION webpdv.cria_transacao_sapi()
  RETURNS INT
  BEGIN
	DECLARE l_int_xano INT;
	SELECT MAX(xano) + 1 INTO l_int_xano FROM sapi.xa;
	INSERT INTO sapi.xa SET xano = l_int_xano;
	RETURN  l_int_xano;
    END;
