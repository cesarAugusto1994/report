CREATE PROCEDURE conhecimento_transporte_excluir(IN conhecimentoTransporteId INT)
  BEGIN
        DELETE FROM webpdv.conhecimento_transporte_compl
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;
        DELETE FROM webpdv.conhecimento_transporte_emitente
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;
        DELETE FROM webpdv.conhecimento_transporte_dest
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;
        DELETE FROM webpdv.conhecimento_transporte_expedidor
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;
		DELETE FROM webpdv.conhecimento_transporte_dup
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;
        DELETE FROM webpdv.conhecimento_transporte_cobr
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;
        DELETE FROM webpdv.conhecimento_transporte_icms
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;
        DELETE FROM webpdv.conhecimento_transporte_receb
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;
		DELETE FROM webpdv.conhecimento_transporte_remetente_nf
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;
        DELETE FROM webpdv.conhecimento_transporte_remetente
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;
        DELETE FROM webpdv.conhecimento_transporte_tomador
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;

        DELETE FROM webpdv.conhecimento_transporte_inf_ns
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;

        DELETE FROM webpdv.conhecimento_transporte_xml
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;

		DELETE FROM webpdv.conhecimento_transporte_valor_compl
        where conhecimento_transporte_id = conhecimentoTransporteId;

        DELETE FROM webpdv.conhecimento_transporte_valor
        WHERE conhecimento_transporte_id = conhecimentoTransporteId;

        DELETE FROM webpdv.conhecimento_transporte
        WHERE id = conhecimentoTransporteId;
  END;
