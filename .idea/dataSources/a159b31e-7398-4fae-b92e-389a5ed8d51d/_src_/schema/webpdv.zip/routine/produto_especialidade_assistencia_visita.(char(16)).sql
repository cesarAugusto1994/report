CREATE FUNCTION webpdv.produto_especialidade_assistencia_visita(Prdno CHAR(16))
  RETURNS INT
  BEGIN
declare retorno INT;
SELECT IFNULL(vep.assistencia_visita_especialidade_id,
IFNULL(vec.assistencia_visita_especialidade_id,
IFNULL(vet.assistencia_visita_especialidade_id, 0))) INTO retorno
FROM webpdv.produto pr
LEFT JOIN webpdv.assistencia_visita_especialidade_produto vep ON (vep.tipo = 'prdno' AND vep.prdno = pr.prdno AND vep.ativo = 1)
LEFT JOIN webpdv.assistencia_visita_especialidade_produto vec ON (vec.tipo = 'clno' AND vec.clno = pr.clno AND vec.ativo = 1)
LEFT JOIN webpdv.assistencia_visita_especialidade_produto vet ON (vet.tipo = 'typeno' AND vet.typeno = pr.typeno AND vet.ativo = 1)
WHERE pr.prdno = Prdno;

RETURN retorno;
END;
